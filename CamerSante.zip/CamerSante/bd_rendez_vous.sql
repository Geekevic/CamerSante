-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : jeu. 13 fév. 2025 à 14:30
-- Version du serveur :  10.4.11-MariaDB
-- Version de PHP : 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `bd_rendez_vous`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `id` int(20) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL DEFAULT 'example@gmail.com'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Ceci est la table des administrateurs.';

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `email`) VALUES
(1, 'evic', '1234', 'evicdurel@gmail.com'),
(3, 'brandon', '1234', 'brandon237@gmail.com'),
(4, 'pilate', '1234', 'pilate@gmail.com'),
(5, 'a', 'a', 'a'),
(26, 'codeur', 'java', 'example@gmail.com'),
(27, 'codeur', 'java', 'example@gmail.com'),
(28, 'codeur', 'java', 'example@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `medecin_table`
--

CREATE TABLE `medecin_table` (
  `id` int(20) NOT NULL,
  `nom` varchar(30) NOT NULL,
  `prenom` varchar(30) NOT NULL,
  `specialite` varchar(30) NOT NULL DEFAULT 'Cardiologie',
  `email` varchar(30) NOT NULL DEFAULT 'example@gmail.com',
  `telephone` int(20) NOT NULL DEFAULT 0,
  `adresse` varchar(50) NOT NULL DEFAULT 'Yaoundé',
  `password` varchar(30) NOT NULL DEFAULT '1234'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Ceci est la table des médécins';

--
-- Déchargement des données de la table `medecin_table`
--

INSERT INTO `medecin_table` (`id`, `nom`, `prenom`, `specialite`, `email`, `telephone`, `adresse`, `password`) VALUES
(1, 'Evic', 'Durel', 'Chirugie générale', 'evicdurel@gmail.com', 653378456, 'Eyebe', '1234'),
(2, 'Agbor', 'Bradon', 'Dentiste', 'abg@gmail.com', 654332784, 'Ekie', '1234'),
(3, 'Wamba', 'Pilate', 'Chirugie', 'pilate@gmail.com', 67456778, 'Dallas', '1234'),
(4, 'Shaw', 'Murphy', 'Chirugie spécialisé', 'murphy@yahoo.fr', 764434333, 'Saint-Bon-Aventure', '1234'),
(5, 'Atango', 'Berlin', 'Orthopedie', 'berlinatango@gmail.com', 673235654, 'Don Bosco', '1234'),
(6, 'Marie', 'Curie', 'Chirugie spécialisé', 'curie@gmail.com', 653439034, 'Santa Barbara', '1234'),
(7, 'Thomas', 'Edison', 'Rhumatologie', 'edi@gmail.com', 663123465, 'Ebang', '1234'),
(8, 'Djonkep', 'Phydrische', 'Pneumologie', 'djonkepphy@yahoo.fr', 67132423, 'Nkolmesseng', '1234'),
(9, 'Darwin', 'Charles', 'Soins intensifs', 'darwincharles@gmail.com', 659452781, 'Yaoundé', 'a'),
(10, 'Stephen', 'Hawking', 'Urologie', 'stephehawking@gmail.com', 657124355, 'Mimboman', '1234'),
(11, 'Albert', 'Mura', 'Gastroentérologie', 'a', 654234412, 'Simeyon', 'a'),
(12, 'Taylor', 'Swift', 'Urologie', 'evitay@du', 65571212, 'Ngousso', '1234'),
(13, 'Goham', 'Lucky', 'Dermatologie', 'evi@durel', 654234121, 'Carriere', 'qwq'),
(14, 'Darole', 'madjuikouo', 'Radiologie', 'darolemaj@gmail.con', 65534567, 'Awaie', 'darole'),
(15, 'Astride', 'Carelle', 'Pédiatrie', 'carelleerty@yahoo.fr', 67534567, 'Cradat', '1234'),
(16, 'Rena', 'anastasie', 'Médecine interne', 'reina@gmail.com', 654234213, 'Bonas', '222'),
(17, 'Eliey', 'Dowell', 'Dentiste', 'dowelleliey@gmail.com', 65542121, 'Chapelle Essos', 'asa'),
(18, 'Tyger', 'Wood', 'Anesthésiologie', 'taygerwood@gmail.com', 67743243, 'Nkolkak', 'aa'),
(19, 'Domeni', 'Merveille', 'ORL', 'fdfs@gmail.com', 659488324, 'Fouda', 'dcxz'),
(20, 'Arnold', 'Roman', 'Autre', 'arnoldroman@gmail.com', 65732423, 'Manguier', 'a'),
(21, 'asas', 'dadasds', 'Diabète & endocrinologie', 'asasa', 3123213, 'fdsadas', '123'),
(22, 'ASASD', 'SADS', 'Dentiste', 'XC', 672213213, 'FREDES', 'QWERDF'),
(23, 'Richard', 'Nasri', 'Pneumologie', 'nasri@gmail.com', 654423432, 'Mendong', 'cv');

-- --------------------------------------------------------

--
-- Structure de la table `patient_table`
--

CREATE TABLE `patient_table` (
  `id` int(11) NOT NULL,
  `nom` varchar(30) NOT NULL,
  `prenom` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `genre` varchar(30) NOT NULL,
  `age` int(11) NOT NULL,
  `telephone` int(30) NOT NULL,
  `adresse` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL DEFAULT '1234'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `patient_table`
--

INSERT INTO `patient_table` (`id`, `nom`, `prenom`, `email`, `genre`, `age`, `telephone`, `adresse`, `password`) VALUES
(1, 'Murphy', 'Shaw', 'Rondontiri237@gmail.com', 'Masculin', 23, 65844324, 'cradat', '1234'),
(2, 'Remond', 'Reddinthon', 'remonr@gmail.com', 'Masculin', 55, 65844326, 'Effoulan', '1234'),
(3, 'Yvanna', 'Stacy', 'stacy@gmail.com', 'Féminin', 21, 657145861, 'Ottou', '1234'),
(4, 'Kamga', 'Lesly', 'ines@gmail.com', 'Féminin', 21, 6543, 'TKC', '1234'),
(5, 'Happy', 'D\'Efoulan', 'happyefoulan@gmail.com', 'Masculin', 25, 657155861, 'Efoulan', '1234'),
(6, 'Emmanuel', 'Gall', 'echaimeain@yahoo.fr', 'Masculin', 25, 659851352, 'Bastos', '1234'),
(7, 'Davilla', 'Fotso', 'fotsodavilla@gmail.com', 'Féminin', 21, 659452186, 'Mimboman', '1234'),
(8, 'Adi', 'Abeba', 'adi@gmail.com', 'Masculin', 23, 673244324, 'Mokolo', '1234'),
(9, 'Johna', 'Walker', 'johnawalker@gmail.com', 'Féminin', 25, 678343444, 'Bastos', '1234'),
(10, 'Alasad', 'Ali', 'a', 'Masculin', 23, 675443545, 'Mongo Beti', '1234'),
(11, 'Mandela', 'Nelson', 'mandela@gmail.com', 'Masculin', 57, 678234544, 'Madagascar', 'a'),
(12, 'Miriam', 'Calire', 'miriamcalire@gmail.com', 'Féminin', 54, 653421235, 'Ngoa Ekele', '1234'),
(13, 'Zefouet', 'Christelle', 'zefouetchris@gmail.com', 'Féminin', 32, 653421236, 'Ngoa Ekele', 'a'),
(14, 'ami', 'desa', 'miamor@gmail.com', 'Féminin', 32, 654238622, 'Essos', 'a'),
(15, 'mouna', 'Mballa', 'efe@yohoo.fr', 'Féminin', 25, 654121334, 'Titi-garage', '1234'),
(16, 'Mosali', 'Child', 'children@gmail.com', 'Féminin', 34, 32, 'Bogota', '1234'),
(17, 'Evic', 'Durel', 'devinci@gmail.com', 'Masculin', 21, 653123980, 'Ebang', 'a'),
(18, 'Modli', 'Viviane', 'modliviviane@gmail.com', 'Féminin', 32, 654352343, 'Florida', '23'),
(19, '12', '12', '12', 'Autre', 12, 12, '12', '12'),
(20, 'Tegentchoua', 'Yvan', 'yvanteg@gmail.com', 'Masculin', 22, 678435622, 'Titi-garage', 'tyg'),
(21, 'John', 'Walker', 'johnwalker@gmail.com', 'Masculin', 32, 678343444, 'Bastos', 'asd'),
(22, 'Mbida', 'Remond', 'remondmbida@gmail.com', 'm\'abstenir', 42, 655561311, 'Emana', 'mbida123'),
(23, 'Dova', 'Willy', 'willydovan@yahoo.fr', 'Masculin', 23, 653342311, 'Bonas', '1234'),
(24, 'landry', 'landry', 'landry', 'Masculin', 10, 655555555, 'cradat', '123456');

-- --------------------------------------------------------

--
-- Structure de la table `rdv_table`
--

CREATE TABLE `rdv_table` (
  `id_rdv` int(11) NOT NULL,
  `id_med` int(11) DEFAULT NULL,
  `id_pat` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `heure_debut` varchar(11) NOT NULL,
  `heure_fin` varchar(11) NOT NULL,
  `motif` varchar(100) NOT NULL,
  `valide` varchar(20) NOT NULL DEFAULT 'Pas encore',
  `effectue` varchar(20) NOT NULL DEFAULT 'Pas encore'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `rdv_table`
--

INSERT INTO `rdv_table` (`id_rdv`, `id_med`, `id_pat`, `date`, `heure_debut`, `heure_fin`, `motif`, `valide`, `effectue`) VALUES
(1, 11, 4, '2025-02-03', '6H', '7H20', 'Examen', 'Oui', 'Pas encore'),
(2, 6, 8, '2025-02-04', '8H15', '10H00', 'Consultation', 'Pas encore', 'Pas encore'),
(3, 9, 4, '2025-02-06', '12H', '14H10', 'Consultation', 'Pas encore', 'Pas encore'),
(4, 2, 3, '2025-02-03', '14H30', '16H45', 'Examen', 'Pas encore', 'Pas encore'),
(5, 11, 11, '2025-02-11', '12H00', '14H', 'Demande d\'ordonnance', 'Oui', 'Effectué'),
(6, 9, 11, '2025-02-12', '18H15', '21H20', 'Test de radiographie', 'Pas encore', 'Pas encore'),
(8, 6, 10, '2025-02-12', '5H15', '7H25', 'Examen', 'Pas encore', 'Annulé'),
(9, 7, 10, '2025-02-14', '7H15', '13H30', 'Opération Chirugicale', 'Pas encore', 'Pas encore'),
(10, 7, 10, '2025-04-02', '16H30', '00H00', 'Opération', 'Pas encore', 'Pas encore'),
(11, 4, 10, '2025-02-14', '12H', '15H', 'radio', 'Annulé', 'Pas encore'),
(12, 4, 10, '2025-02-16', '12H', '15H', 'radio', 'Annulé', 'Pas encore'),
(13, 9, 21, '2025-02-11', '12H15', '16H45', 'Consultation', 'Pas encore', 'Pas encore'),
(14, 6, 22, '2025-03-11', '05H30', '07H30', 'Consultation', 'Pas encore', 'Pas encore'),
(15, 12, 10, '2025-02-12', '19H25', '20H45', 'Consultation', 'Rejeté', 'Pas encore'),
(16, 11, 10, '2025-02-12', '11H15', '12H00', 'Consulatation', 'Pas encore', 'Pas encore'),
(17, 11, 10, '2025-02-13', '12H15', '12H30', 'Examen', 'Oui', 'Annulé'),
(18, 11, 10, '2025-02-15', '19H15', '21H35', 'Radiographie', 'Oui', 'Oui'),
(19, 10, 23, '2025-02-13', '11H00', '12H15', 'Ordonance', 'Pas encore', 'Pas encore'),
(20, 4, 24, '2025-02-14', '14h15', '19H20', 'Consultation', 'Oui', 'Oui'),
(21, 12, 24, '2025-02-11', '11H00', '12H25', 'Consultation', 'Annulé', 'Pas encore'),
(22, 11, 24, '2025-02-11', '12H15', '15H15', 'Examen', 'Rejeté', 'Pas encore');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `medecin_table`
--
ALTER TABLE `medecin_table`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `patient_table`
--
ALTER TABLE `patient_table`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `rdv_table`
--
ALTER TABLE `rdv_table`
  ADD PRIMARY KEY (`id_rdv`),
  ADD KEY `etrangere` (`id_pat`,`id_med`),
  ADD KEY `recevoir` (`id_med`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT pour la table `medecin_table`
--
ALTER TABLE `medecin_table`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT pour la table `patient_table`
--
ALTER TABLE `patient_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT pour la table `rdv_table`
--
ALTER TABLE `rdv_table`
  MODIFY `id_rdv` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `rdv_table`
--
ALTER TABLE `rdv_table`
  ADD CONSTRAINT `demander` FOREIGN KEY (`id_pat`) REFERENCES `patient_table` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `recevoir` FOREIGN KEY (`id_med`) REFERENCES `medecin_table` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
