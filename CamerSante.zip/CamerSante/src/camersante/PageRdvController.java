/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camersante;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.Initializable;
import javafx.stage.Stage;

import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author Administrateur
 */
public class PageRdvController implements Initializable {

    @FXML
    private ImageView closeBtn;

    @FXML
    private TableColumn<Rdv, String> date_col;

    @FXML
    private TableColumn<Rdv, String> debut_col;

    @FXML
    private TableColumn<Rdv, String> fait_col;

    @FXML
    private TableColumn<Rdv, String> fin_col;

    @FXML
    private TableColumn<Rdv, Integer> idMed_col;

    @FXML
    private TableColumn<Rdv, Integer> idPat_col;

    @FXML
    private TableColumn<Rdv, Integer> id_rdv_col;

    @FXML
    private TableColumn<Rdv, String> motif_col;

    @FXML
    private ImageView reduireBtn;

    @FXML
    private TextField search_Rdv;

    @FXML
    private TableView<Rdv> table_Rdv;
    
    @FXML
    private TableColumn<Rdv, String> valide_col;

    @FXML
    void close(MouseEvent event) {
        closeBtn.getScene().getWindow().hide();
    }

    @FXML
    void minimize(MouseEvent event) {
        Stage stage = (Stage)reduireBtn.getScene().getWindow();
        stage.setIconified(true);
    }

   
    private Connection connect = null;
    private PreparedStatement prepare;
    private Statement statement;
    private ResultSet result;
    
    //Methode permettant d'ajouter un medecin a la liste des medecins dans la BD
    public ObservableList<Rdv> addRdvDonnees(){
        
        ObservableList<Rdv> listData = FXCollections.observableArrayList();
        
        String sql = "SELECT * FROM rdv_table";
        
        //connecter le tableau a la base de donnees
        connect = Database.connectDb();
        
        try{
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();
            
            Rdv rdvD;
            
            while(result.next()){
                rdvD = new Rdv(result.getInt("id_rdv")
                        , result.getInt("id_med")   
                        , result.getInt("id_pat")
                        , result.getString("date")
                        , result.getString("heure_debut")
                        , result.getString("heure_fin")
                        , result.getString("motif")
                        , result.getString("valide")
                        , result.getString("effectue"));
                
                //ajouter MedecinD a la liste des medecins
                listData.add(rdvD);
            }
            
                connect.close();
                prepare.close();
                result.close();
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("***********Echec recuperation de donnees************");
        }
        return listData;
    }
    
    //afficher un medecin dans le tableau de gauche 
    ObservableList<Rdv> addRdvList = FXCollections.observableArrayList();
    public void addRdvTableau(){
        addRdvList = addRdvDonnees();
        
        //l'identifiant de chaque colonne du tableau table_Medecin prend la valeur 
        //comprise dans chaque colonne de la medecin_table
        
        id_rdv_col.setCellValueFactory(new PropertyValueFactory<Rdv, Integer>("idRdv"));
        idMed_col.setCellValueFactory(new PropertyValueFactory<Rdv, Integer>("idMed"));
        idPat_col.setCellValueFactory(new PropertyValueFactory<Rdv, Integer>("idPat"));
        date_col.setCellValueFactory(new PropertyValueFactory<Rdv, String>("date"));
        debut_col.setCellValueFactory(new PropertyValueFactory<Rdv, String>("heureDebut"));
        fin_col.setCellValueFactory(new PropertyValueFactory<Rdv, String>("heureFin"));                  
        motif_col.setCellValueFactory(new PropertyValueFactory<Rdv, String>("motif"));
        valide_col.setCellValueFactory(new PropertyValueFactory<Rdv, String>("valide"));
        fait_col.setCellValueFactory(new PropertyValueFactory<Rdv, String>("effectue"));
        
        table_Rdv.setItems(addRdvList);
    }
    
    public void searchRdv(){
        FilteredList<Rdv> filter = new FilteredList<>(addRdvList, e-> true);
        
        search_Rdv.textProperty().addListener((Observable, oldValue, newValue)->{
            
            filter.setPredicate(predicateRdv ->{
                
                if(newValue == null || newValue.isEmpty()){
                    return false;
                }
                String searchKey = newValue;
                
                if(predicateRdv.idRdvProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicateRdv.idMedProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicateRdv.idPatProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicateRdv.dateProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicateRdv.heureDebutProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicateRdv.heureFinProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicateRdv.motifProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicateRdv.valideProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicateRdv.effectueProperty().toString().contains(searchKey)){
                    return true;
                }else{return false;}
            });
        });
        
        SortedList<Rdv> sortlist = new SortedList<>(filter);
        
        sortlist.comparatorProperty().bind(table_Rdv.comparatorProperty());
        table_Rdv.setItems(sortlist);
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        addRdvTableau();
    }    
    
}
