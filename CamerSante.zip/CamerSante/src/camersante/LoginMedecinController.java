/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camersante;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author Administrateur
 */
public class LoginMedecinController implements Initializable {

    
    @FXML
    private AnchorPane close_rose;
    
    @FXML
    private AnchorPane backBtn;

    @FXML
    private Button connexionBtn;

    @FXML
    private TextField email_Medecin;

    @FXML
    private Label enregistrerLink;

    @FXML
    private AnchorPane main_form;

    @FXML
    private PasswordField password_Medecin;

    @FXML
    void close(MouseEvent event) {
        System.exit(0);
    }

    @FXML
    void connexionMedecin(ActionEvent event) throws IOException{
        String sql = "SELECT * FROM medecin_table WHERE email = ? and password = ?";
        
        connect  = Database.connectDb();
        
   
        try{
            Alert alert;
            
            if(email_Medecin.getText().isEmpty()){
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Message d'erreur");
                alert.setHeaderText(null);
                alert.setContentText("Veuillez entrer votre email.");
                alert.showAndWait();
            }else if(password_Medecin.getText().isEmpty()){
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Message d'erreur");
                alert.setHeaderText(null);
                alert.setContentText("Veuillez entrer votre mot de passe.");
                alert.showAndWait();
            }else{
                prepare = connect.prepareStatement(sql);
                prepare.setString(1, email_Medecin.getText());
                prepare.setString(2, password_Medecin.getText());
                
                result = prepare.executeQuery();
                
                if(result.next()){
                    
                    //recuperer l'id a travers l'email
                    //THEN PROCEED TO DASHBOARD
                    
                    
                    //***********************recuper l'id d'un email****************
                    String sql2 = "SELECT id FROM medecin_table WHERE email = '"+email_Medecin.getText()+"'";
                    Connection connect2 = null;
                    connect2 = Database.connectDb();
                    PreparedStatement prepare2 = connect2.prepareStatement(sql2);
                    ResultSet result2;
                    
                    
                    try{
                        result2 = prepare.executeQuery();
                        if(result2.next()){
                            int i = result2.getInt("id");
                            GetterMedecin.id = i;
                        }
                    }catch(Exception e){
                    System.out.print("Probleme de lecture 1");
                    }
                    connect2.close();
                    //*****************************************
                            
                    
                    alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Information");
                    alert.setHeaderText(null);
                    alert.setContentText("Connexion validé !");
                    alert.showAndWait();
                    
                    //_________________________aller a une autre page
                    //Masquer l'interface de connexion
                    connexionBtn.getScene().getWindow().hide();
                    
                    //pour lier l'interface d'accueil Admmin
                    Parent root = FXMLLoader.load(getClass().getResource("PageMedecin.fxml"));
                    Stage stage = new Stage();
                    Scene scene = new Scene(root);
                    stage.initStyle(StageStyle.TRANSPARENT);
                    
                    stage.setScene(scene);
                    stage.show();
                    
                    
                    //________________________________________________
                    
                }else{
                    
                    //Au cas ou le nom d'utilisateur ou le mot de passe est incorrect
                    alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Message d'erreur");
                    alert.setHeaderText(null);
                    alert.setContentText("L'email ou le mot de passe est incorrect." + "\n" + "Veuillez recommencer s'il vous plait !");
                    alert.showAndWait();
                }
            }
        }catch(Exception e){e.printStackTrace();}
    }

    @FXML
    void signUp(MouseEvent event) throws IOException{

        enregistrerLink.getScene().getWindow().hide();
                    
                    //pour lier l'interface d'accueil Admmin
                    Parent root = FXMLLoader.load(getClass().getResource("SignUpMedecin.fxml"));
                    Stage stage = new Stage();
                    Scene scene = new Scene(root);
                    //le rendre invisible
                    stage.initStyle(StageStyle.TRANSPARENT);
                    
                    stage.setScene(scene);
                    stage.show();
    }
    
    private Connection connect = null;
    private PreparedStatement prepare;
    private ResultSet result;
    
    private double x = 0;
    private double y = 0;
    
    public void goToIndex() throws IOException{
                    //Masquer l'interface de connexion
                    backBtn.getScene().getWindow().hide();
                    
                    //pour lier l'interface d'accueil Admmin
                    Parent root = FXMLLoader.load(getClass().getResource("Index.fxml"));
                    Stage stage = new Stage();
                    Scene scene = new Scene(root);
                    
                    //le rendre invisible
                    stage.initStyle(StageStyle.TRANSPARENT);
                    
                    stage.setScene(scene);
                    stage.show();
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    
    
}
