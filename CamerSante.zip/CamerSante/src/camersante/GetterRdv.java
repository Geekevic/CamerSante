/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camersante;

/**
 *
 * @author Administrateur
 */
public class GetterRdv {
    public static int idRdv;
    public static int idMed;
    public static int idPat;
    public static String date;
    public static String heureDebut;
    public static String heurefin;
    public static String motif;
    public static String effectue;
}
