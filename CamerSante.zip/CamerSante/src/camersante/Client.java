/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camersante;

/**
 *
 * @author Administrateur
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author Administrateur
 */
public class Client {
    
    public static void main(String[] args) throws IOException{
        try{
           int port = 4000;
            Socket socClient = new Socket("127.0.0.1", port);
            System.out.println("Client pret a envoyer");

            InputStream fluxln = socClient.getInputStream();
            InputStreamReader isr = new InputStreamReader(fluxln);
            BufferedReader fluxLect = new BufferedReader(isr);

            OutputStream fluxOut = socClient.getOutputStream();
            PrintStream fluxEcr = new PrintStream(fluxOut);
            
            Scanner scan = new Scanner(System.in);
            String message = scan.nextLine();
            
            while(!message.equals("Fin")){
                fluxEcr.print(message + "\n");
                
                //
                String msgrecu = fluxLect.readLine();
                System.out.println(msgrecu);
                message = scan.nextLine();
            }
       }catch(Exception e){
           System.out.println("L'erreur est :" + e.getMessage());
       }
    }
    
}
