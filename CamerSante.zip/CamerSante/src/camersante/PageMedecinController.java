/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camersante;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;

/**
 * FXML Controller class
 *
 * @author Administrateur
 */
public class PageMedecinController implements Initializable {

    @FXML
    private TextField Message_ChampSaisie;

    @FXML
    private Button Message_EnvoyerBtn;

    @FXML
    private AnchorPane Message_anchorPane;

    @FXML
    private AnchorPane Rdv_anchorPane;

    @FXML
    private TableColumn<Rdv, String> Rdv_date_tb;

    @FXML
    private TableColumn<Rdv, String> Rdv_heureDebut_tb;

    @FXML
    private TableColumn<Rdv, String> Rdv_heureFin_tb;

    @FXML
    private TableColumn<Rdv, Integer> Rdv_id_tb;

    @FXML
    private TableColumn<Rdv, String> Rdv_motif_tb;

    @FXML
    private Button Rdv_rejeter_btn;

    @FXML
    private TableView<Rdv> Rdv_tableView;

    @FXML
    private Button Rdv_valider_btn;

    @FXML
    private AnchorPane accueil_medecin;

    @FXML
    private AnchorPane agenda_AnchorPane;

    @FXML
    private Button agenda_anuuler_btn;

    @FXML
    private TableColumn<Rdv, String> agenda_date_tb;

    @FXML
    private Button agenda_effectue_btn;

    @FXML
    private TableColumn<Rdv, String> agenda_effectue_tb;

    @FXML
    private TableColumn<Rdv, String> agenda_heure_debut_tb;

    @FXML
    private TableColumn<Rdv, String> agenda_heure_fin_tb;

    @FXML
    private TableColumn<Rdv, Integer> agenda_id_tb_Patient;

    @FXML
    private TableColumn<Rdv, String> agenda_motif_tb;

    @FXML
    private TableView<Rdv> agenda_tableView;

    @FXML
    private Button btn_Agenda;

    @FXML
    private Button btn_Messages;

    @FXML
    private Button btn_Profil;

    @FXML
    private Button btn_RDV;

    @FXML
    private Button close_red;

    @FXML
    private Button deconnexion_btn;

    @FXML
    private Text id_rdv_cache;

    @FXML
    private AnchorPane main_form;

    @FXML
    private Button minimize_btn;

    @FXML
    private AnchorPane profile_AnchorPane;

    @FXML
    private TextField profile_adresse_Medecin_field;

    @FXML
    private TextField profile_email_Medecin_field;

    @FXML
    private Button profile_enregistrerBtn;

    @FXML
    private Label profile_id;

    @FXML
    private Text profile_mon_adresse;

    @FXML
    private Text profile_mon_email;

    @FXML
    private Text profile_mon_nom;

    @FXML
    private Text profile_mon_prenom;

    @FXML
    private Text profile_mon_specialite;

    @FXML
    private Text profile_mon_telephone;

    @FXML
    private TextField profile_nom_Medecin_field;

    @FXML
    private TextField profile_prenom_Medecin_field;

    @FXML
    private ComboBox<?> profile_specialite_Medecin_field;

    @FXML
    private TextField profile_telephone_Medecin_field;

    @FXML
    private Label usernameMedecin;

    @FXML
    void annulerRdv(ActionEvent event) {
        
        String sql = "UPDATE rdv_table SET effectue = 'Annulé' WHERE id_rdv = '"
                +id_rdv_cache.getText()+"'";
        
        connect = Database.connectDb();
        
        try{
            Alert alert;
            //prepare = connect.prepareStatement(sql);
            
            if(id_rdv_cache.getText().toString() == "0"){
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Message d'erreur");
                alert.setHeaderText(null);
                alert.setContentText("Veuillez selectionner un rendez-vous avant de l'annuler.");
                alert.showAndWait();
            }else{
                
                
                    //next code
                    //______________________________________
                
                    alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("Attention");
                    alert.setHeaderText(null);
                    alert.setContentText("Souhaitez-vous vraiment annuler ce rendez-vous ?");
                    Optional<ButtonType> option = alert.showAndWait();

                    if(option.get().equals(ButtonType.OK)){
                        statement = connect.createStatement();
                        statement.executeUpdate(sql);

                        alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Information");
                        alert.setHeaderText(null);
                        alert.setContentText("Rendez-vous annulé avec success !");
                        alert.showAndWait();

                        //mettre a jour les champs
                        actualiserAgenda();
                        id_rdv_cache.setText("0");
                        //connect.close();
                    }
                
                //______________________________________
            }
            }catch(Exception e){e.printStackTrace();}
    }


    @FXML
    void effectuerRdv(ActionEvent event) {
        
        String sql = "UPDATE rdv_table SET effectue = 'Oui' WHERE id_rdv = '"
                +id_rdv_cache.getText()+"'";
        
        connect = Database.connectDb();
        
        try{
            Alert alert;
            //prepare = connect.prepareStatement(sql);
            
            if(id_rdv_cache.getText().toString() == "0"){
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Message d'erreur");
                alert.setHeaderText(null);
                alert.setContentText("Veuillez selectionner un rendez-vous avant de le rendre effectif.");
                alert.showAndWait();
            }else{
                
                
                    //next code
                    //______________________________________
                
                    alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("Attention");
                    alert.setHeaderText(null);
                    alert.setContentText("Souhaitez-vous marquer ce rendez-vous effectif ?");
                    Optional<ButtonType> option = alert.showAndWait();

                    if(option.get().equals(ButtonType.OK)){
                        statement = connect.createStatement();
                        statement.executeUpdate(sql);

                        alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Information");
                        alert.setHeaderText(null);
                        alert.setContentText("Rendez-vous effectué avec success !");
                        alert.showAndWait();

                        //connect.close();
                        actualiserAgenda();
                        id_rdv_cache.setText("0");
                    }
                
                //______________________________________
            }
            }catch(Exception e){e.printStackTrace();}
    }


    @FXML
    void rejeterRdv(ActionEvent event) {

        String sql = "UPDATE rdv_table SET valide = 'Rejeté' WHERE id_rdv = '"
                +id_rdv_cache.getText()+"'";
        
        connect = Database.connectDb();
        
        try{
            Alert alert;
            //prepare = connect.prepareStatement(sql);
            
            if(id_rdv_cache.getText().toString() == "0"){
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Message d'erreur");
                alert.setHeaderText(null);
                alert.setContentText("Veuillez selectionner un rendez-vous avant de le rejeter.");
                alert.showAndWait();
            }else{
                
                
                    //next code
                    //______________________________________
                
                    alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("Attention");
                    alert.setHeaderText(null);
                    alert.setContentText("Souhaitez-vous vraiment rejeter cette demande de rendez-vous ?");
                    Optional<ButtonType> option = alert.showAndWait();

                    if(option.get().equals(ButtonType.OK)){
                        statement = connect.createStatement();
                        statement.executeUpdate(sql);

                        alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Information");
                        alert.setHeaderText(null);
                        alert.setContentText("Cette demande de rendez-vous a été rejeté avec success !");
                        alert.showAndWait();

                        //mettre a jour les champs
                        actualiserTableauRdv();
                        id_rdv_cache.setText("0");
                        //connect.close();
                    }
                
                //______________________________________
            }
            }catch(Exception e){e.printStackTrace();}
    }

    @FXML
    void selectRdv(MouseEvent event) {
        try{
            Rdv RdvD = (Rdv) Rdv_tableView.getSelectionModel().getSelectedItem();
        
            int num;

            num = Rdv_tableView.getSelectionModel().getFocusedIndex();

            //System.out.println(num);

            if((num -1) < -1){return;}

            id_rdv_cache.setText(String.valueOf(RdvD.getIdRdv()));
            
        
        }catch(Exception e){
            System.out.println("****Probleme de selection de rdv****");
            e.printStackTrace();
        }
    }
    
    @FXML
    void selectRdvAgenda(MouseEvent event) {
        try{
            Rdv RdvD = (Rdv) agenda_tableView.getSelectionModel().getSelectedItem();
        
            int num;

            num = agenda_tableView.getSelectionModel().getFocusedIndex();

            //System.out.println(num);

            if((num -1) < -1){return;}

            id_rdv_cache.setText(String.valueOf(RdvD.getIdRdv()));
            
        
        }catch(Exception e){
            System.out.println("****Probleme de selection de rdv****");
            e.printStackTrace();
        }
    }


    @FXML
    void validerRdv(ActionEvent event) {

        String sql = "UPDATE rdv_table SET valide = 'Oui' WHERE id_rdv = '"
                +id_rdv_cache.getText()+"'";
        
        connect = Database.connectDb();
        
        try{
            Alert alert;
            //prepare = connect.prepareStatement(sql);
            
            if(id_rdv_cache.getText().toString() == "0"){
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Message d'erreur");
                alert.setHeaderText(null);
                alert.setContentText("Veuillez selectionner un rendez-vous avant de le valider.");
                alert.showAndWait();
            }else{
                
                
                    //next code
                    //______________________________________
                
                    alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("Attention");
                    alert.setHeaderText(null);
                    alert.setContentText("Souhaitez-vous vraiment valider cette demande de rendez-vous ?");
                    Optional<ButtonType> option = alert.showAndWait();

                    if(option.get().equals(ButtonType.OK)){
                        statement = connect.createStatement();
                        statement.executeUpdate(sql);

                        alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Information");
                        alert.setHeaderText(null);
                        alert.setContentText("Cette demande de rendez-vous a été validé avec success !");
                        alert.showAndWait();

                        //mettre a jour les champs
                        actualiserTableauRdv();
                        id_rdv_cache.setText("0");
                        //connect.close();
                    }
                
                //______________________________________
            }
            }catch(Exception e){e.printStackTrace();}
    }
    /**
     * Initializes the controller class.
     * @param event
     */
    int ident = GetterMedecin.id;
    
    private Connection connect = null;
    private PreparedStatement prepare;
    private Statement statement;
    private ResultSet result;
    
    //XXXXXXXXXXXXXXX___BLOC DE FENETRE ET NAVIGATION___XXXXXXXXXXXXXXXXXXXXXXXXX
    
    private String[] specialiteList = {
        "Anesthésiologie","Cardiologie","Chirugie générale","Chirugie spécialisé", "Dentiste", "Dermatologie",
        "Diabète & endocrinologie","Gastroentérologie","Gynéco-Obstétrique","Gynecologie","Hématologie",
        "Maladies infectueuses/VIH","Médecine du travail","Médecine générale","Médecine interne",
        "Médecine physique","Néphrologie","Neurologie","Oncologie","Orthopedie", "ORL", 
        "Pédiatrie","Pneumologie","Psychiatrie","Radiologie", "Rhumatologie",
        "Soins intensifs", "Urologie", "Autre"};
    
    public void addMedecinSpecialiteList(){
        List<String> listS = new ArrayList<>();
        
        for(String Data : specialiteList){
            listS.add(Data);
        }
        
        ObservableList listD = FXCollections.observableArrayList(listS);
        profile_specialite_Medecin_field.setItems(listD);
    }
    public void updatePatient(){
        
        String requeteUpdate = "UPDATE medecin_table SET nom = '"
                +profile_nom_Medecin_field.getText()+"', prenom = '"
                +profile_prenom_Medecin_field.getText()+"', specialite = '"
                +profile_specialite_Medecin_field.getSelectionModel().getSelectedItem()+"', email = '"
                +profile_email_Medecin_field.getText()+"', telephone = '"
                +profile_telephone_Medecin_field.getText()+"', adresse = '"
                +profile_adresse_Medecin_field.getText()+"' WHERE id = '"
                +profile_id.getText()+"'";
        
        connect = Database.connectDb();
        
        try{
            Alert alert;
            //prepare = connect.prepareStatement(sql);
            
            if(profile_nom_Medecin_field.getText().isEmpty() 
                    || profile_prenom_Medecin_field.getText().isEmpty() 
                    || profile_specialite_Medecin_field.getSelectionModel().getSelectedItem() == null 
                    || profile_email_Medecin_field.getText().isEmpty() 
                    || profile_telephone_Medecin_field.getText().isEmpty() 
                    || profile_adresse_Medecin_field.getText().isEmpty()){
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Message d'erreur");
                alert.setHeaderText(null);
                alert.setContentText("Veuillez remplir tous les champs");
                alert.showAndWait();
            }else{
                alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Attention");
                alert.setHeaderText(null);
                alert.setContentText("Souhaitez-vous vraiment modifier vos informations ?");
                Optional<ButtonType> option = alert.showAndWait();
                
                if(option.get().equals(ButtonType.OK)){
                    //prepare = connect.createStatement();
                    
                    connect.createStatement().executeUpdate(requeteUpdate);
                    
                    alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Information");
                    alert.setHeaderText(null);
                    alert.setContentText("Modifications effectuées avec success !");
                    alert.showAndWait();
                    
                    //liberer la connexion
                    //connect.close();
                    //prepare.close();
                }
            }
            afficherMesInfos();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public void afficherMesInfos() throws SQLException{
       //String user = GetterPatient.username;
        
        //usernamePatient.setText(user.substring(0, 1).toLowerCase() + user.substring(1));
        int ident = GetterMedecin.id;
        
        profile_id.setText(""+ ident);
        
       
        //***************************************
                


                try{
                    String sql2 = "SELECT nom, prenom,specialite, email, telephone, adresse FROM medecin_table WHERE id = '"+profile_id.getText()+"'";
                    Connection connect2 = null;
                    connect2 = Database.connectDb();
                    PreparedStatement prepare2 = connect2.prepareStatement(sql2);
                    ResultSet result2;
                    //prepare2.setString(0, profile_id.getText());
                    //prepare2.setInt(0, ident);

                    try{
                        
                        result2 = prepare2.executeQuery();
                        if(result2.next()){
                            //int i = result2.getInt("id");
                            System.out.print("****************************************");
                            usernameMedecin.setText(result2.getString("prenom"));
                            profile_mon_nom.setText(result2.getString("nom"));
                            profile_mon_prenom.setText(result2.getString("prenom")+".");
                            profile_mon_specialite.setText(result2.getString("specialite"));
                            profile_mon_email.setText(result2.getString("email"));
                            profile_mon_telephone.setText(result2.getString("telephone"));
                            profile_mon_adresse.setText(result2.getString("adresse")+".");
                        }
                    }catch(Exception e){
                    System.out.print("Probleme de lecture 1");
                    e.printStackTrace();
                }
                }catch(Exception e){
                    System.out.print("Probleme de lecture 2");
                    e.printStackTrace();
                }
        //*****************************************
        
    }
    
    public void defaultSettings(){
        btn_RDV.setStyle("-fx-background-color: #2280dd;");
        Rdv_anchorPane.setVisible(true);
        id_rdv_cache.setText("0");
    }
    public void switchForm(ActionEvent event){
        if(event.getSource() == btn_RDV){
            Rdv_anchorPane.setVisible(true);
            agenda_AnchorPane.setVisible(false);
            profile_AnchorPane.setVisible(false);
            Message_anchorPane.setVisible(false);
            
            btn_RDV.setStyle("-fx-background-color: #2280dd;");
            btn_Agenda.setStyle("-fx-background-color: transparent;");
            btn_Profil.setStyle("-fx-background-color: transparent;");
            btn_Messages.setStyle("-fx-background-color: transparent;");
            
            actualiserTableauRdv();
            id_rdv_cache.setText("0");
            
        }else if(event.getSource() == btn_Agenda){
            Rdv_anchorPane.setVisible(false);
            agenda_AnchorPane.setVisible(true);
            profile_AnchorPane.setVisible(false);
            Message_anchorPane.setVisible(false);   
            
            btn_Agenda.setStyle("-fx-background-color: #2280dd;");
            btn_RDV.setStyle("-fx-background-color: transparent;");
            btn_Profil.setStyle("-fx-background-color: transparent;");
            btn_Messages.setStyle("-fx-background-color: transparent;");
            
            actualiserAgenda();
            id_rdv_cache.setText("0");
            
            
        }else if(event.getSource() == btn_Profil){
            Rdv_anchorPane.setVisible(false);
            agenda_AnchorPane.setVisible(false);
            profile_AnchorPane.setVisible(true);
            Message_anchorPane.setVisible(false);
            
            btn_Profil.setStyle("-fx-background-color: #2280dd;");
            btn_RDV.setStyle("-fx-background-color: transparent;");
            btn_Agenda.setStyle("-fx-background-color: transparent;");
            btn_Messages.setStyle("-fx-background-color: transparent;");
            
            id_rdv_cache.setText("0");
            
        }else if(event.getSource() == btn_Messages){
            Rdv_anchorPane.setVisible(false);
            agenda_AnchorPane.setVisible(false);
            profile_AnchorPane.setVisible(false);
            Message_anchorPane.setVisible(true);
            
            btn_Profil.setStyle("-fx-background-color: transparent;");
            btn_RDV.setStyle("-fx-background-color: transparent;");
            btn_Agenda.setStyle("-fx-background-color: transparent;");
            btn_Messages.setStyle("-fx-background-color: #2280dd;");
            
            id_rdv_cache.setText("0");
            
        }
    }
    
    private double x = 0;
    private double y = 0;
    
    public void logout(){
        try{
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Message d'erreur");
            alert.setHeaderText(null);
            alert.setContentText("Voulez-vous vraiment vous déconnecter ?");
            
            Optional<ButtonType> option = alert.showAndWait();
            
            if(option.get().equals(ButtonType.OK)){
                
                //masquer la fenetre Admin
                deconnexion_btn.getScene().getWindow().hide();
                
                Parent root = FXMLLoader.load(getClass().getResource("loginMedecin.fxml"));
                Stage stage = new Stage();
                Scene scene = new Scene(root);
                
                //sous pression de la souris
                root.setOnMousePressed((MouseEvent event) ->{

                    x = event.getSceneX(); 
                    y = event.getSceneY();
                });

                //sur glissement de la souris
                root.setOnMouseDragged((MouseEvent event) ->{

                    stage.setX(event.getSceneX() - x);
                    stage.setY(event.getSceneY() - y);
                });
                //le rendre invisible
                stage.initStyle(StageStyle.TRANSPARENT);
                    
                stage.setScene(scene);
                stage.show();
            }
        }catch(Exception e){e.printStackTrace();}
    }
    
    public void close(){
        System.exit(0);
    }
    
    public void minimize(){
        Stage stage = (Stage)main_form.getScene().getWindow();
        stage.setIconified(true);
    }
    //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
    
    //XXXXXXXXXXXXXXX___BLOC DE RDV entrants___XXXXXXXXXXXXXXXXXXXXXXXXX
    
    public ObservableList<Rdv> contruireRdvRecu(){
        
        ObservableList<Rdv> listData = FXCollections.observableArrayList();
        
        String sql = "SELECT * FROM rdv_table WHERE id_Med ='"+ident+"'AND valide LIKE 'Pas encore'";
        
        //connecter le tableau a la base de donnees
        connect = Database.connectDb();
        
        try{
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();
            Rdv RdvD;
            
            while(result.next()){
                RdvD = new Rdv(result.getInt("id_rdv")
                        , result.getInt("id_med")   
                        , result.getInt("id_pat")
                        , result.getString("date")
                        , result.getString("heure_debut")
                        , result.getString("heure_fin")
                        , result.getString("motif")
                        , result.getString("valide")
                        , result.getString("effectue"));
                
                //ajouter MedecinD a la liste des medecins
                listData.add(RdvD);
            }
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("***********Echec CONSTRUCTION de Rdv Recu************");
        }
        
        return listData;
    }
    
    ObservableList<Rdv> listeRdv = FXCollections.observableArrayList();
    public void actualiserTableauRdv(){
        listeRdv = contruireRdvRecu();
        
        Rdv_id_tb.setCellValueFactory(new PropertyValueFactory<Rdv, Integer>("idPat"));
        Rdv_date_tb.setCellValueFactory(new PropertyValueFactory<Rdv, String>("date"));
        Rdv_heureDebut_tb.setCellValueFactory(new PropertyValueFactory<Rdv, String>("heureDebut"));
        Rdv_heureFin_tb.setCellValueFactory(new PropertyValueFactory<Rdv, String>("heureFin"));                  
        Rdv_motif_tb.setCellValueFactory(new PropertyValueFactory<Rdv, String>("motif"));
        
        Rdv_tableView.setItems(listeRdv);
        
    }
    
    public ObservableList<Rdv> contruireRdvAgenda(){
        
        ObservableList<Rdv> listData = FXCollections.observableArrayList();
        
        String sql = "SELECT * FROM rdv_table WHERE id_Med ='"+ident+"' AND valide LIKE 'Oui' AND effectue LIKE 'Pas encore'";
        
        //connecter le tableau a la base de donnees
        connect = Database.connectDb();
        
        try{
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();
            Rdv RdvD;
            
            while(result.next()){
                RdvD = new Rdv(result.getInt("id_rdv")
                        , result.getInt("id_med")   
                        , result.getInt("id_pat")
                        , result.getString("date")
                        , result.getString("heure_debut")
                        , result.getString("heure_fin")
                        , result.getString("motif")
                        , result.getString("valide")
                        , result.getString("effectue"));
                
                //ajouter MedecinD a la liste des medecins
                listData.add(RdvD);
            }
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("***********Echec CONSTRUCTION de Rdv Recu************");
        }
        
        return listData;
    }
    
    ObservableList<Rdv> listeAgenda = FXCollections.observableArrayList();
    public void actualiserAgenda(){
        listeAgenda = contruireRdvAgenda();
        
        agenda_id_tb_Patient.setCellValueFactory(new PropertyValueFactory<Rdv, Integer>("idPat"));
        agenda_date_tb.setCellValueFactory(new PropertyValueFactory<Rdv, String>("date"));
        agenda_heure_debut_tb.setCellValueFactory(new PropertyValueFactory<Rdv, String>("heureDebut"));
        agenda_heure_fin_tb.setCellValueFactory(new PropertyValueFactory<Rdv, String>("heureFin"));                  
        agenda_motif_tb.setCellValueFactory(new PropertyValueFactory<Rdv, String>("motif"));
        
        agenda_tableView.setItems(listeAgenda);
        
    }
    //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        defaultSettings();
        try {
            // TODO
            afficherMesInfos();
        } catch (SQLException ex) {
            Logger.getLogger(PageMedecinController.class.getName()).log(Level.SEVERE, null, ex);
        }
        addMedecinSpecialiteList();
        actualiserTableauRdv();
        actualiserAgenda();
        
    }    
    
}
