/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package camersante;

import java.sql.Connection;
import java.sql.DriverManager;


public class Database {
    
    public static Connection connectDb(){
        
        try{     
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Driver chargé avec succès");
            //Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/bd_rendez_vous?zeroDataTimeBehavior=convertToNull", "root", "");
            //Connection connect = DriverManager.getConnection("jdbc:derby://localhost:1527/mydatabase", "evic", "1234");//database linkm, username, password
            
            String url = "jdbc:mysql://localhost:3306/bd_rendez_vous";
            String usr = "root";    String pw = "";
            Connection connect = (Connection) DriverManager.getConnection(url, usr, pw);
            System.out.println("Connexion établie avec succéss");
            return connect;
            
        }catch(Exception e){e.printStackTrace();}
        
        return null;
    }
}
