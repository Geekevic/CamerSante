/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camersante;

/**
 *
 * @author Administrateur
 */
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author Administrateur
 */
public class Serveur {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int port = 4000;
        try{
            ServerSocket socServ = new ServerSocket(port);
                    
//            
            System.out.println("Serveur lance");
            
            Socket socCL = socServ.accept();
            System.out.println("Connexion acceptee");
                
                
            java.io.InputStream fluxln = socCL.getInputStream();
            InputStreamReader isr = new InputStreamReader(fluxln);
            BufferedReader fluxLect = new BufferedReader(isr);
            
            PrintStream fluxEcr = new PrintStream(socCL.getOutputStream());
            String msgRecu = fluxLect.readLine();
            System.out.println(fluxEcr);
            System.out.println(socCL.getInetAddress() + ": " + msgRecu);
            
            Scanner scan = new Scanner(System.in);
            String message = scan.nextLine();
            
            while(!message.equals("Fin")){
                
                fluxEcr.print(message + "\n");
                System.out.println(message);
                
                System.out.println(socCL.getInetAddress() + ": " + fluxLect.readLine());
                message = scan.nextLine();
            }
            
           
        }catch(Exception e){
            System.out.println("L'erreur est "+ e.getMessage());
        }
    }
    
}