/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camersante;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;

/**
 * FXML Controller class
 *
 * @author Administrateur
 */
public class PagePatientController implements Initializable {

    
    @FXML
    private TextField Message_ChampSaisie;

    @FXML
    private Button Message_EnvoyerBtn;

    @FXML
    private AnchorPane Message_anchorPane;

    @FXML
    private AnchorPane Profile_anchorPane;

    @FXML
    private Button Rdv_Annuler;

    @FXML
    private Button Rdv_EnvoyerBtn;

    @FXML
    private TextField Rdv_HeureDebut;

    @FXML
    private TextField Rdv_HeureFin;

    @FXML
    private TableColumn<Rdv, String> Rdv_heureFin_col;

    @FXML
    private Button Rdv_ListMedBtn;

    @FXML
    private AnchorPane Rdv_anchorPane;

    @FXML
    private DatePicker Rdv_date;

    @FXML
    private TableColumn<Rdv, String> Rdv_date_col;

    @FXML
    private TableColumn<Rdv, String> Rdv_effectue_col;

    @FXML
    private TableColumn<Rdv, String> Rdv_heureDebut_col;

    @FXML
    private TextField Rdv_idMed;

    @FXML
    private TableColumn<Rdv, Integer> Rdv_idMed_col;

    @FXML
    private TextField Rdv_motif;

    @FXML
    private TableColumn<Rdv, String> Rdv_motif_col;
    
    @FXML
    private TableColumn<Rdv, String> Rdv_valide_col;

    @FXML
    private AnchorPane accueil_medecin;

    @FXML
    private Button btn_Messages;

    @FXML
    private Button btn_Profile;

    @FXML
    private Button btn_RDV;

    @FXML
    private Button close_red;

    @FXML
    private Button deconnexion_btn;
    
    @FXML
    private Text id_rdv_cache;

    @FXML
    private AnchorPane main_form;

    @FXML
    private Button minimize_btn;

    @FXML
    private TextField profile_adresse_patient_field;

    @FXML
    private TextField profile_age_patient_field;

    @FXML
    private TextField profile_email_patient_field;

    @FXML
    private Button profile_enregistrerBtn;

    @FXML
    private ComboBox<?> profile_genre_patient_field;

    @FXML
    private Label profile_id;

    @FXML
    private Text profile_mon_adresse;

    @FXML
    private Text profile_mon_age;

    @FXML
    private Text profile_mon_email;

    @FXML
    private Text profile_mon_genre;

    @FXML
    private Text profile_mon_nom;

    @FXML
    private Text profile_mon_prenom;

    @FXML
    private Text profile_mon_telephone;

    @FXML
    private TextField profile_nom_patient_field;

    @FXML
    private TextField profile_prenom_patient_field;

    @FXML
    private TextField profile_telephone_patient_field;

    @FXML
    private TableView<Rdv> table_Rdv_Patient;

    @FXML
    private Label usernamePatient;
    
    @FXML
    void voirListMedecin(ActionEvent event) throws IOException{
        //pour lier l'interface d'accueil Admmin
                    Parent root = FXMLLoader.load(getClass().getResource("ListMedecin.fxml"));
                    Stage stage = new Stage();
                    Scene scene = new Scene(root);
                    //le rendre invisible
                    stage.initStyle(StageStyle.TRANSPARENT);
                    
                    stage.setScene(scene);
                    stage.show();
    }
//    @FXML
//    void deletePatient(ActionEvent event) {
//
//    }
    
    private String[] genreList = {"Masculin", "Féminin", "Autre", "m'abstenir"};
    
    private Connection connect = null;
    private PreparedStatement prepare;
    private Statement statement;
    private ResultSet result;
    
    int ident = GetterPatient.id;
    
    
    Connection cx;
    
    PreparedStatement prep;
    Statement state;
    
    //______________Methode d'ajout le genre___________________________
    
    public void addMedecinGenreList(){
        List<String> listS = new ArrayList<>();
        
        for(String Data : genreList){
            listS.add(Data);
        }
        
        ObservableList listD = FXCollections.observableArrayList(listS);
        profile_genre_patient_field.setItems(listD);
    }
    public void updatePatient(){
        
        String requeteUpdate = "UPDATE patient_table SET nom = '"
                +profile_nom_patient_field.getText()+"', prenom = '"
                +profile_prenom_patient_field.getText()+"', genre = '"
                +profile_genre_patient_field.getSelectionModel().getSelectedItem()+"', email = '"
                +profile_email_patient_field.getText()+"', telephone = '"
                +profile_telephone_patient_field.getText()+"', age = '"
                +profile_age_patient_field.getText()+"', adresse = '"
                +profile_adresse_patient_field.getText()+"' WHERE id = '"
                +profile_id.getText()+"'";
        
        connect = Database.connectDb();
        
        try{
            Alert alert;
            //prepare = connect.prepareStatement(sql);
            
            if(profile_age_patient_field.getText().isEmpty() 
                    || profile_nom_patient_field.getText().isEmpty() 
                    || profile_prenom_patient_field.getText().isEmpty() 
                    || profile_genre_patient_field.getSelectionModel().getSelectedItem() == null 
                    || profile_email_patient_field.getText().isEmpty() 
                    || profile_telephone_patient_field.getText().isEmpty() 
                    || profile_adresse_patient_field.getText().isEmpty()){
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Message d'erreur");
                alert.setHeaderText(null);
                alert.setContentText("Veuillez remplir tous les champs");
                alert.showAndWait();
            }else{
                alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Attention");
                alert.setHeaderText(null);
                alert.setContentText("Souhaitez-vous vraiment modifier vos informations ?");
                Optional<ButtonType> option = alert.showAndWait();
                
                if(option.get().equals(ButtonType.OK)){
                    //prepare = connect.createStatement();
                    
                    connect.createStatement().executeUpdate(requeteUpdate);
                    
                    alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Information");
                    alert.setHeaderText(null);
                    alert.setContentText("Modifications effectuées avec success !");
                    alert.showAndWait();
                }
            }
            afficherMesInfos();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    //XXXXXXXXXXXXXXX___BLOC DE FENETRE ET NAVIGATION___XXXXXXXXXXXXXXXXXXXXXXXXX
    
    public void afficherMesInfos() throws SQLException{
        
        profile_id.setText(""+ ident);
        
       
        //***************************************
                


                try{
                    String sql2 = "SELECT nom, prenom, email, age, genre, telephone, adresse FROM patient_table WHERE id = '"+profile_id.getText()+"'";
                    Connection connect2 = null;
                    connect2 = Database.connectDb();
                    PreparedStatement prepare2 = connect2.prepareStatement(sql2);
                    ResultSet result2;

                    try{
                        
                        result2 = prepare2.executeQuery();
                        if(result2.next()){
                            //int i = result2.getInt("id");
                            System.out.print("****************************************");
                            usernamePatient.setText(result2.getString("prenom"));
                            profile_mon_nom.setText(result2.getString("nom"));
                            profile_mon_prenom.setText(result2.getString("prenom")+".");
                            profile_mon_email.setText(result2.getString("email"));
                            profile_mon_genre.setText(result2.getString("genre")+".");
                            profile_mon_age.setText(result2.getString("age"));
                            profile_mon_telephone.setText(result2.getString("telephone"));
                            profile_mon_adresse.setText(result2.getString("adresse")+".");
                        }
                    }catch(Exception e){
                    System.out.print("Probleme de lecture 1");
                    e.printStackTrace();
                }
                }catch(Exception e){
                    System.out.print("Probleme de lecture 2");
                    e.printStackTrace();
                }
        //*****************************************
        
    }
    //Afficher les differentes interfaces apres appuis sur un bouton
    
    public void defaultBtn(){
        btn_RDV.setStyle("-fx-background-color: #2280dd;");
        Rdv_anchorPane.setVisible(true);
        Message_anchorPane.setVisible(false);
        Profile_anchorPane.setVisible(false);
    }
    @FXML
    public void switchForm(ActionEvent event){
        if(event.getSource() == btn_RDV){
            Rdv_anchorPane.setVisible(true);
            Message_anchorPane.setVisible(false);
            Profile_anchorPane.setVisible(false);
            
            btn_RDV.setStyle("-fx-background-color: #2280dd;");
            btn_Messages.setStyle("-fx-background-color: transparent;");
            btn_Profile.setStyle("-fx-background-color: transparent;");
            
            ajouterRdvTableau();
            
        }else if(event.getSource() == btn_Messages){
            Rdv_anchorPane.setVisible(false);
            Message_anchorPane.setVisible(true);
            Profile_anchorPane.setVisible(false);   
            
            btn_Messages.setStyle("-fx-background-color: #2280dd;");
            btn_RDV.setStyle("-fx-background-color: transparent;");
            btn_Profile.setStyle("-fx-background-color: transparent;");
            
        }else if(event.getSource() == btn_Profile){
            Rdv_anchorPane.setVisible(false);
            Message_anchorPane.setVisible(false);
            Profile_anchorPane.setVisible(true);
            
            btn_Profile.setStyle("-fx-background-color: #2280dd;");
            btn_RDV.setStyle("-fx-background-color: transparent;");
            btn_Messages.setStyle("-fx-background-color: transparent;");
        }
    }
    
    @FXML
    public void logout(){
        try{
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Message d'erreur");
            alert.setHeaderText(null);
            alert.setContentText("Voulez-vous vraiment vous déconnecter ?");
            
            Optional<ButtonType> option = alert.showAndWait();
            
            if(option.get().equals(ButtonType.OK)){
                
                //masquer la fenetre Admin
                deconnexion_btn.getScene().getWindow().hide();
                
                Parent root = FXMLLoader.load(getClass().getResource("loginPatient.fxml"));
                Stage stage = new Stage();
                Scene scene = new Scene(root);
                //le rendre invisible
                stage.initStyle(StageStyle.TRANSPARENT);
                    
                stage.setScene(scene);
                stage.show();
            }
        }catch(Exception e){e.printStackTrace();}
    }
    
    @FXML
    public void close(){
        System.exit(0);
    }
    
    @FXML
    public void minimize(){
        Stage stage = (Stage)main_form.getScene().getWindow( );
        stage.setIconified(true);
    }
    
    //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
    
    //XXXXXXXXXXXXXXXXXXXXXXXXX___BLOC DE MEDECIN___XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
    //inserer un rdv a la BD
    public void addRdvBd(){
        String sql = "insert into rdv_table (id_med, id_pat, date, heure_debut, heure_fin, motif) VALUES(?,?,?,?,?,?)";
        
        connect = Database.connectDb();
        
        try{
            Alert alert;
            //prepare = connect.prepareStatement(sql);
            
            if(Rdv_idMed.getText().isEmpty() 
                    || Rdv_HeureDebut.getText().isEmpty() 
                    || Rdv_HeureFin.getText().isEmpty() 
                    || Rdv_date.getValue().equals("")
                    || Rdv_motif.getText().isEmpty()){
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Message d'erreur");
                alert.setHeaderText(null);
                alert.setContentText("Veuillez remplir tous les champs.");
                alert.showAndWait();
            }else{
                
                String checkData = ("SELECT id FROM medecin_table WHERE id = '"
                        +Rdv_idMed.getText()+"'");
                
                statement = connect.createStatement();
                result = statement.executeQuery(checkData);
                
                if(!result.next()){
                    alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Aucun médecin ne possède l'identifiant: "+Rdv_idMed.getText()+".");
                    alert.setHeaderText(null);
                    alert.setContentText("Veuillez consulter la liste des médecins et entrez un identifiant correct.");
                    alert.showAndWait();
                }else{

                    cx = Database.connectDb();

                    prep = (PreparedStatement) cx.prepareStatement(sql);
                    
                    LocalDate dateSelect = Rdv_date.getValue();
                    
                    prep.setString(1, Rdv_idMed.getText());
                    prep.setInt(2, ident);
                    prep.setString(3, dateSelect.toString());
                    prep.setString(4, Rdv_HeureDebut.getText());
                    prep.setString(5, Rdv_HeureFin.getText());
                    prep.setString(6, Rdv_motif.getText());
                    
                    prep.executeUpdate();
                    
                    //affiche le message 'Ajoutez'
                    alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Information");
                    alert.setHeaderText(null);
                    alert.setContentText("Prise de rendez-vous effectuée !"
                    +"\n"+"En attente de validation du médecin...");
                    alert.showAndWait();
                    
                    //fonctions
                    ajouterRdvTableau();
                }
                //
            }
            connect.close();
            prepare.close();
           
        }catch(Exception e){
            System.out.println("________________________________________"+"\n");
            e.printStackTrace();
            System.out.println(".........Probleme de connexion.........");
        }
    }
    
    //Methode permettant de construire un objet de type rdv a partir de la BD de rdv
    public ObservableList<Rdv> contruireRdv(){
        
        ObservableList<Rdv> listData = FXCollections.observableArrayList();
        
        String sql = "SELECT * FROM rdv_table WHERE id_Pat ='"+ident+"'";
        
        //connecter le tableau a la base de donnees
        connect = Database.connectDb();
        
        try{
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();
            Rdv RdvD;
            
            while(result.next()){
                RdvD = new Rdv(result.getInt("id_rdv")
                        , result.getInt("id_med")   
                        , result.getInt("id_pat")
                        , result.getString("date")
                        , result.getString("heure_debut")
                        , result.getString("heure_fin")
                        , result.getString("motif")
                        , result.getString("valide")
                        , result.getString("effectue"));
                
                //ajouter MedecinD a la liste des medecins
                listData.add(RdvD);
            }
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("***********Echec addList************");
        }
        
        return listData;
    }
    
    //afficher un rdv dans le tableau de rdv
    ObservableList<Rdv> listeRdv = FXCollections.observableArrayList();
    public void ajouterRdvTableau(){
        listeRdv = contruireRdv();
        
        //l'identifiant de chaque colonne du tableau table_Medecin prend la valeur 
        //comprise dans chaque colonne de la medecin_table
        
        Rdv_idMed_col.setCellValueFactory(new PropertyValueFactory<Rdv, Integer>("idMed"));
        Rdv_date_col.setCellValueFactory(new PropertyValueFactory<Rdv, String>("date"));
        Rdv_heureDebut_col.setCellValueFactory(new PropertyValueFactory<Rdv, String>("heureDebut"));
        Rdv_heureFin_col.setCellValueFactory(new PropertyValueFactory<Rdv, String>("heureFin"));                  
        Rdv_motif_col.setCellValueFactory(new PropertyValueFactory<Rdv, String>("motif"));
        Rdv_valide_col.setCellValueFactory(new PropertyValueFactory<Rdv, String>("valide"));
        Rdv_effectue_col.setCellValueFactory(new PropertyValueFactory<Rdv, String>("effectue"));
        
        table_Rdv_Patient.setItems(listeRdv);
        
    }
    
    public void selectRdv(){
        
        try{
            Rdv RdvD = (Rdv) table_Rdv_Patient.getSelectionModel().getSelectedItem();
        
            int num;

            num = table_Rdv_Patient.getSelectionModel().getFocusedIndex();

            //System.out.println(num);

            if((num -1) < -1){return;}

            id_rdv_cache.setText(String.valueOf(RdvD.getIdRdv()));
            
        
        }catch(Exception e){
            System.out.println("****Probleme de selection de rdv****");
            e.printStackTrace();
        }
    }
    
    public void annulerRdv(){
        
        String sql = "UPDATE rdv_table SET valide = 'Annulé' WHERE id_rdv = '"
                +id_rdv_cache.getText()+"'";
        
        connect = Database.connectDb();
        
        try{
            Alert alert;
            //prepare = connect.prepareStatement(sql);
            
            if(id_rdv_cache.getText().toString() == "0"){
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Message d'erreur");
                alert.setHeaderText(null);
                alert.setContentText("Veuillez selectionner un rendez-vous avant de l'annuler.");
                alert.showAndWait();
            }else{
                Connection cx;
                cx = Database.connectDb();
                Statement st;
                ResultSet rs;
                
                String checkData = ("SELECT * FROM rdv_table WHERE ((valide LIKE 'Rejeté') OR (effectue IN ('Oui', 'Annulé'))) AND id_rdv = '"+id_rdv_cache.getText()+"'");
                
                st = cx.createStatement();
                rs = st.executeQuery(checkData);
                
                if(rs.next()){
                    alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Opération inutile");
                    alert.setHeaderText(null);
                    alert.setContentText("Vous ne pouvez pas annuler ce rendez-vous car il a déjà été soit effectué, soit rejeté, ou annulé par ce médecin.");
                    alert.showAndWait();
                }else{
                
                    st.close();
                    cx.close();
                    rs.close();
                    //next code
                    //______________________________________
                
                    alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("Attention");
                    alert.setHeaderText(null);
                    alert.setContentText("Souhaitez-vous vraiment annuler ce rendez-vous ?");
                    Optional<ButtonType> option = alert.showAndWait();

                    if(option.get().equals(ButtonType.OK)){
                        statement = connect.createStatement();
                        statement.executeUpdate(sql);

                        alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Information");
                        alert.setHeaderText(null);
                        alert.setContentText("Ce rendez-vous a été annulé avec success !");
                        alert.showAndWait();

                        //mettre a jour les champs
                        ajouterRdvTableau();
                        //connect.close();
                }
                
                //______________________________________
                }
            }
            id_rdv_cache.setText("0");
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        try {
            // TODO
            afficherMesInfos();
        } catch (SQLException ex) {
            Logger.getLogger(PagePatientController.class.getName()).log(Level.SEVERE, null, ex);
        }
        defaultBtn();
        addMedecinGenreList();
        ajouterRdvTableau();
        id_rdv_cache.setText("0");
    }    
    
}
