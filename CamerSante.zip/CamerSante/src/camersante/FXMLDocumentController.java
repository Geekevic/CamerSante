/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package camersante;

import java.io.IOException;
import static java.lang.Math.sqrt;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author Administrateur
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private AnchorPane close_rose;
    
    @FXML
    private AnchorPane backBtn;

    @FXML
    private Button connexionBtn;

    @FXML
    private AnchorPane main_form;

    @FXML
    private PasswordField password;

    @FXML
    private TextField username;

    private Connection connect = null;
    private PreparedStatement prepare;
    private ResultSet result;
    
    private double x = 0;
    private double y = 0;
    
    //procedure adminLogin pour gerer la conformite du login des administrateurs
    public void adminLogin() throws IOException{
        
        String sql = "SELECT * FROM admin WHERE username = ? and password = ?";
        
        connect  = Database.connectDb();
        
   
        try{
            Alert alert;
            
            if(username.getText().isEmpty()){
                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Message d'erreur");
                alert.setHeaderText(null);
                alert.setContentText("Veuillez entrer un nom d'utilisateur");
                alert.showAndWait();
            }else if(password.getText().isEmpty()){
                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Message d'erreur");
                alert.setHeaderText(null);
                alert.setContentText("Veuillez entrer votre mot de passe");
                alert.showAndWait();
            }else{
                prepare = connect.prepareStatement(sql);
                prepare.setString(1, username.getText());
                prepare.setString(2, password.getText());
                
                result = prepare.executeQuery();
                
                if(result.next()){
                    
                    //THEN PROCEED TO DASHBOARD
                    //*************************
                    GetterDonnees.username = username.getText();
                    
                    
                    
                    
                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information");
                    alert.setHeaderText(null);
                    alert.setContentText("Connexion validé !");
                    alert.showAndWait();
                    
                    //Masquer l'interface de connexion
                    connexionBtn.getScene().getWindow().hide();
                    
                    //pour lier l'interface d'accueil Admmin
                    Parent root = FXMLLoader.load(getClass().getResource("Dashboard.fxml"));
                    Stage stage = new Stage();
                    Scene scene = new Scene(root);

                    

                    //sous pression de la souris
                    root.setOnMousePressed((MouseEvent event) ->{

                        x = event.getSceneX();
                        y = event.getSceneY();
                    });

                    //sur glissement de la souris
                    root.setOnMouseDragged((MouseEvent event) ->{

                        stage.setX(event.getSceneX() - x);
                        stage.setY(event.getSceneY() - y);
                    });
                    //le rendre invisible
                    stage.initStyle(StageStyle.TRANSPARENT);
                    
                    stage.setScene(scene);
                    stage.show();
                    
                }else{
                    
                    //Au cas ou le nom d'utilisateur ou le mot de passe est incorrect
                    alert = new Alert(AlertType.ERROR);
                    alert.setTitle("Message d'erreur");
                    alert.setHeaderText(null);
                    alert.setContentText("Le nom d'utilisateur ou le mot de passe est incorrect." + "\n" + "Veuillez recommencer s'il vous plait !");
                    alert.showAndWait();
                }
            }
        }catch(Exception e){e.printStackTrace();}
    }
          
    //pour fermer la fenetre
    public void close(){
        System.exit(0);
    }
    
    public void goToIndex() throws IOException{
                    //Masquer l'interface de connexion
                    backBtn.getScene().getWindow().hide();
                    
                    //pour lier l'interface d'accueil Admmin
                    Parent root = FXMLLoader.load(getClass().getResource("Index.fxml"));
                    Stage stage = new Stage();
                    Scene scene = new Scene(root);
                    
                    //le rendre invisible
                    stage.initStyle(StageStyle.TRANSPARENT);
                    
                    stage.setScene(scene);
                    stage.show();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}