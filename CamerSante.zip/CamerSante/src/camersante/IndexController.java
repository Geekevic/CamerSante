/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camersante;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author Administrateur
 */
public class IndexController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private Text adminLink;

    @FXML
    private AnchorPane admin_btn;
    
    @FXML
    private AnchorPane reduiseBtn;


    @FXML
    private Button connexionM;

    @FXML
    private Button connexionP;

    @FXML
    void loginAdmin(MouseEvent event) throws IOException{

        admin_btn.getScene().getWindow().hide();
                    
                    //pour lier l'interface d'accueil Admmin
                    Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
                    Stage stage = new Stage();
                    Scene scene = new Scene(root);
                    //le rendre invisible
                    stage.initStyle(StageStyle.TRANSPARENT);
                    
                    stage.setScene(scene);
                    stage.show();
    }

    @FXML
    void loginMedecin(ActionEvent event) throws IOException{

        connexionM.getScene().getWindow().hide();
                    
                    //pour lier l'interface d'accueil Admmin
                    Parent root = FXMLLoader.load(getClass().getResource("loginMedecin.fxml"));
                    Stage stage = new Stage();
                    Scene scene = new Scene(root);
                    //le rendre invisible
                    stage.initStyle(StageStyle.TRANSPARENT);
                    
                    stage.setScene(scene);
                    stage.show();
    }

    @FXML
    void loginPatient(ActionEvent event) throws IOException{

        connexionP.getScene().getWindow().hide();
                    
                    //pour lier l'interface d'accueil Admmin
                    Parent root = FXMLLoader.load(getClass().getResource("loginPatient.fxml"));
                    Stage stage = new Stage();
                    Scene scene = new Scene(root);
                    //le rendre invisible
                    stage.initStyle(StageStyle.TRANSPARENT);
                    
                    stage.setScene(scene);
                    stage.show();
    }
    
    public void minimize(){
        Stage stage = (Stage)reduiseBtn.getScene().getWindow();
        stage.setIconified(true);
    }
    public void close(){
        System.exit(0);
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
