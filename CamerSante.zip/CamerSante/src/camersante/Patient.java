/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camersante;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author Administrateur
 * 
 */
public class Patient {
    IntegerProperty idPat = new SimpleIntegerProperty();
    StringProperty nomPat = new SimpleStringProperty();
    StringProperty prenomPat = new SimpleStringProperty();
    StringProperty emailPat = new SimpleStringProperty();
    StringProperty genrePat = new SimpleStringProperty();
    IntegerProperty agePat = new SimpleIntegerProperty();
    IntegerProperty telPat = new SimpleIntegerProperty();
    StringProperty adressePat = new SimpleStringProperty();
    
    public Patient(int idPat, String nomPat, String prenomPat, String emailPat, String genrePat, int agePat, int telPat, String adressePat){
        this.idPat = new SimpleIntegerProperty(idPat);
        this.nomPat= new SimpleStringProperty(nomPat);
        this.prenomPat = new SimpleStringProperty(prenomPat);
        this.emailPat = new SimpleStringProperty(emailPat);
        this.genrePat = new SimpleStringProperty(genrePat);
        this.agePat = new SimpleIntegerProperty(agePat);
        this.telPat = new SimpleIntegerProperty(telPat);
        this.adressePat = new SimpleStringProperty(adressePat);
    }

    public int getIdPat() {
      return idPat.get();
    }   
    public IntegerProperty idPatProperty() {
      return idPat;
    }
    public void setIdPat(int idPat) {
      this.idPat.set(idPat);
    }
    
    public String getNomPat() {
      return nomPat.get();
    }
    public StringProperty nomPatProperty() {
      return nomPat;
    }
    public void setNomPat(String nomPat) {
      this.nomPat.set(nomPat);
    }
  
    public String getPrenomPat() {
      return prenomPat.get();
    }
    public StringProperty prenomPatProperty() {
      return prenomPat;
    }
    public void setPrenomPat(String prenomPat) {
      this.prenomPat.set(prenomPat);
    }
    
    public String getEmailPat() {
      return emailPat.get();
    }
    public StringProperty emailPatProperty() {
      return emailPat;
    }
    public void setEmailPat(String emailPat) {
      this.emailPat.set(emailPat);
    }
    
    public String getGenrePat() {
      return genrePat.get();
    }
    public StringProperty genrePatProperty() {
      return genrePat;
    }
    public void setGenrePat(String genrePat) {
      this.genrePat.set(genrePat);
    }
    
    public int getAgePat() {
      return agePat.get();
    }
    public IntegerProperty agePatProperty() {
      return agePat;
    }
    public void setAgePat(int idPat) {
      this.agePat.set(idPat);
    }
    
    public int getTelPat() {
      return telPat.get();
    }
    public IntegerProperty telPatProperty() {
      return telPat;
    }
    public void setTelPat(int idPat) {
      this.telPat.set(idPat);
    }
    
    public String getAdressePat() {
      return adressePat.get();
    }
    public StringProperty adressePatProperty() {
      return adressePat;
    }
    public void setAdressePat(String adressePat) {
      this.adressePat.set(adressePat);
    }
    
}