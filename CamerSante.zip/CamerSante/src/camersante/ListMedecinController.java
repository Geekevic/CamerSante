/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camersante;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.Initializable;

import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
/**
 * FXML Controller class
 *
 * @author Administrateur
 */
public class ListMedecinController implements Initializable {

    
    /**
     * Initializes the controller class.
     */
    
    @FXML
    private TableColumn<Medecin, String> adresse_col;

    @FXML
    private ImageView closeBtn;

    @FXML
    private TableColumn<Medecin, String> email_col;

    @FXML
    private TableColumn<Medecin, Integer> id_col;

    @FXML
    private TableColumn<Medecin, String> nom_col;

    @FXML
    private TableColumn<Medecin, String> prenom_col;

    @FXML
    private ImageView reduireBtn;

    @FXML
    private TextField search_Medecin;

    @FXML
    private TableColumn<Medecin, String> specialite_col;

    @FXML
    private TableView<Medecin> table_Medecin;

    @FXML
    private TableColumn<Medecin, Integer> telephone_col;

    @FXML
    void close(MouseEvent event) {
        closeBtn.getScene().getWindow().hide();
    }

    @FXML
    void minimize(MouseEvent event) {
        Stage stage = (Stage)reduireBtn.getScene().getWindow();
        stage.setIconified(true);
    }

    
    
    private Connection connect = null;
    private PreparedStatement prepare;
    private Statement statement;
    private ResultSet result;
    
    //Methode permettant d'ajouter un medecin a la liste des medecins dans la BD
    public ObservableList<Medecin> addMedecinDonnees(){
        
        ObservableList<Medecin> listData = FXCollections.observableArrayList();
        
        String sql = "SELECT * FROM medecin_table";
        
        //connecter le tableau a la base de donnees
        connect = Database.connectDb();
        
        try{
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();
            Medecin MedecinD;
            
            while(result.next()){
                MedecinD = new Medecin(result.getInt("id")
                        , result.getString("nom")
                        , result.getString("prenom")
                        , result.getString("specialite")
                        , result.getString("email")
                        , result.getInt("telephone")
                        , result.getString("adresse"));
                
                //ajouter MedecinD a la liste des medecins
                listData.add(MedecinD);
            }
            
                connect.close();
                prepare.close();
                result.close();
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("***********Echec addList************");
        }
        return listData;
    }
    
    //afficher un medecin dans le tableau de gauche 
    ObservableList<Medecin> addMedecinList = FXCollections.observableArrayList();
    public void addMedecinTableau(){
        addMedecinList = addMedecinDonnees();
        
        //l'identifiant de chaque colonne du tableau table_Medecin prend la valeur 
        //comprise dans chaque colonne de la medecin_table
        
        id_col.setCellValueFactory(new PropertyValueFactory<Medecin, Integer>("idMed"));
        nom_col.setCellValueFactory(new PropertyValueFactory<Medecin, String>("nomMed"));
        prenom_col.setCellValueFactory(new PropertyValueFactory<Medecin, String>("prenomMed"));
        specialite_col.setCellValueFactory(new PropertyValueFactory<Medecin, String>("specialiteMed"));                  
        email_col.setCellValueFactory(new PropertyValueFactory<Medecin, String>("emailMed"));
        telephone_col.setCellValueFactory(new PropertyValueFactory<Medecin, Integer>("telMed"));
        adresse_col.setCellValueFactory(new PropertyValueFactory<Medecin, String>("adresseMed"));
        
        table_Medecin.setItems(addMedecinList);
        
    }
    
    public void searchMedecin(){
        FilteredList<Medecin> filter = new FilteredList<>(addMedecinList, e-> true);
        
        search_Medecin.textProperty().addListener((Observable, oldValue, newValue)->{
            
            filter.setPredicate(predicateMedecin ->{
                
                if(newValue == null || newValue.isEmpty()){
                    return false;
                }
                String searchKey = newValue;
                
                if(predicateMedecin.idMedProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicateMedecin.nomMedProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicateMedecin.prenomMedProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicateMedecin.specialiteMedProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicateMedecin.emailMedProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicateMedecin.telMedProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicateMedecin.adresseMedProperty().toString().contains(searchKey)){
                    return true;
                }else{return false;}
            });
        });
        
        SortedList<Medecin> sortlist = new SortedList<>(filter);
        
        sortlist.comparatorProperty().bind(table_Medecin.comparatorProperty());
        table_Medecin.setItems(sortlist);
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        addMedecinTableau();
    }    
    
}
