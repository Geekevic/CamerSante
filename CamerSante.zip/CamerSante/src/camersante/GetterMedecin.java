/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camersante;

/**
 *
 * @author Administrateur
 */
public class GetterMedecin {
    public static String username;
    public static int id;
}
