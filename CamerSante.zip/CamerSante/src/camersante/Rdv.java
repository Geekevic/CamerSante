/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camersante;

import java.sql.Date;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author Administrateur
 */
public class Rdv {
    IntegerProperty idRdv = new SimpleIntegerProperty();
    IntegerProperty idMed = new SimpleIntegerProperty();
    IntegerProperty idPat = new SimpleIntegerProperty();
    StringProperty date = new SimpleStringProperty();
    StringProperty heureDebut = new SimpleStringProperty();
    StringProperty heureFin = new SimpleStringProperty();
    StringProperty motif = new SimpleStringProperty();
    StringProperty valide = new SimpleStringProperty();
    StringProperty effectue = new SimpleStringProperty();

    public Rdv(int idRdv, int idMed, int idPat, String date, String heureDebut, String heureFin, String motif, String valide, String effectue){
        this.idRdv = new SimpleIntegerProperty(idRdv);
        this.idMed = new SimpleIntegerProperty(idMed);
        this.idPat = new SimpleIntegerProperty(idPat);
        this.date = new SimpleStringProperty(date);
        this.heureDebut = new SimpleStringProperty(heureDebut);
        this.heureFin = new SimpleStringProperty(heureFin);
        this.motif = new SimpleStringProperty(motif);
        this.valide = new SimpleStringProperty(valide);
        this.effectue = new SimpleStringProperty(effectue);
    }
    
    public int getIdRdv() {
      return idRdv.get();
    }   
    public IntegerProperty idRdvProperty() {
      return idRdv;
    }
    public void setIdRdv(int idRdv) {
      this.idRdv.set(idRdv);
    }
    
    public int getIdMed() {
      return idMed.get();
    }   
    public IntegerProperty idMedProperty() {
      return idMed;
    }
    public void setIdMed(int idMed) {
      this.idMed.set(idMed);
    }
    
    public int getIdPat() {
      return idPat.get();
    }   
    public IntegerProperty idPatProperty() {
      return idPat;
    }
    public void setIdPat(int idPat) {
      this.idPat.set(idPat);
    }
    
    public String getDate() {
      return date.get();
    }   
    public StringProperty dateProperty() {
      return date;
    }
    public void setIdPat(String date) {
      this.date.set(date);
    }
    
    public String getHeureDebut() {
      return heureDebut.get();
    }   
    public StringProperty heureDebutProperty() {
      return heureDebut;
    }
    public void setHeureDebut(String heureDebut) {
      this.heureDebut.set(heureDebut);
    }
    
    public String getHeureFin() {
      return heureFin.get();
    }   
    public StringProperty heureFinProperty() {
      return heureFin;
    }
    public void setHeureFin(String heureFin) {
      this.heureFin.set(heureFin);
    }
    
    public String getValide() {
      return valide.get();
    }
    public StringProperty valideProperty() {
      return valide;
    }
    public void setValide(String valide) {
      this.valide.set(valide);
    }
    
    public String getEffectue() {
      return effectue.get();
    }
    public StringProperty effectueProperty() {
      return effectue;
    }
    public void setEffectue(String effectue) {
      this.effectue.set(effectue);
    }
    
    public String getMotif() {
      return motif.get();
    }
    public StringProperty motifProperty() {
      return motif;
    }
    public void setMotif(String motif) {
      this.motif.set(motif);
    }
}
