/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package camersante;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Administrateur
 */
public class CamerSante extends Application {
    
    static PreparedStatement pst;
    static Connection con = null;
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("Index.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }
    
    /*
    //_________________________________________________________
    public static void driver(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Driver chargé avec succès");
        }catch(Exception e){
        System.out.println("Driver non chargé "+e.getMessage());
        }
    }
    
    //_________________________________________________________
    public static void connection(){
        try{
            String url = "jdbc:mysql://localhost:3306/bd_rendez_vous";
            String usr = "root";    String pw = "";
            con = (Connection) DriverManager.getConnection(url, usr, pw);
            System.out.println("Connexion établie avec succéss");
        }catch(Exception e){
        System.out.println("Echec connexion ..."+e.getMessage());
        }
    }
    
    //__________________________________________________________________

    
    public static void insert(){
        try{
            String requete = "INSERT INTO admin (username, password) values(?, ?)";
            pst = (PreparedStatement) con.prepareStatement(requete);
            pst.setString(1, "codeur");
            pst.setString(2, "java");
            
            System.out.println("Ajout d'un nouvel admin réalisé avec succés");
            
            pst.executeUpdate();
            
            System.out.println("_______________________________________________________");
            
        }catch(Exception e){
        System.out.println("Echec d'ajout... "+e.getMessage());
        }
    }
    
    */
    //_________________________________________________________
    /**
     * @param args the command line arguments
     */
    
    
    public static void main(String[] args) {
        //driver();
        //connection();
        //insert();
        launch(args);
    }
    
}
