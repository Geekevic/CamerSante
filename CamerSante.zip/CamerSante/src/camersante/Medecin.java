/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camersante;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author Administrateur
 */
public class Medecin {
    IntegerProperty idMed = new SimpleIntegerProperty();
    StringProperty nomMed = new SimpleStringProperty();
    StringProperty prenomMed = new SimpleStringProperty();
    StringProperty specialiteMed = new SimpleStringProperty();
    StringProperty emailMed = new SimpleStringProperty();
    IntegerProperty telMed = new SimpleIntegerProperty();
    StringProperty adresseMed = new SimpleStringProperty();
    
    public Medecin(int idMed, String nomMed, String prenomMed, String specialiteMed, String emailMed, int telMed, String adresseMed){
        this.idMed = new SimpleIntegerProperty(idMed);
        this.nomMed = new SimpleStringProperty(nomMed);
        this.prenomMed = new SimpleStringProperty(prenomMed);
        this.specialiteMed = new SimpleStringProperty(specialiteMed);
        this.emailMed = new SimpleStringProperty(emailMed);
        this.telMed = new SimpleIntegerProperty(telMed);
        this.adresseMed = new SimpleStringProperty(adresseMed);
    }
    
    public int getIdMed() {
      return idMed.get();
    }   
    public IntegerProperty idMedProperty() {
      return idMed;
    }
    public void setIdMed(int idMed) {
      this.idMed.set(idMed);
    }
    
    public String getNomMed() {
      return nomMed.get();
    }
    public StringProperty nomMedProperty() {
      return nomMed;
    }
    public void setNomMed(String nomMed) {
      this.nomMed.set(nomMed);
    }
  
    public String getPrenomMed() {
      return prenomMed.get();
    }
    public StringProperty prenomMedProperty() {
      return prenomMed;
    }
    public void setPrenomMed(String prenomMed) {
      this.prenomMed.set(prenomMed);
    }
    
    public String getSpecialiteMed() {
      return specialiteMed.get();
    }
    public StringProperty specialiteMedProperty() {
      return specialiteMed;
    }
    public void setSpecialiteMed(String specialiteMed) {
      this.specialiteMed.set(specialiteMed);
    }
    
    public String getEmailMed() {
      return emailMed.get();
    }
    public StringProperty emailMedProperty() {
      return emailMed;
    }
    public void setEmailMed(String emailMed) {
      this.emailMed.set(emailMed);
    }
    
    public int getTelMed() {
      return telMed.get();
    }
    public IntegerProperty telMedProperty() {
      return telMed;
    }
    public void setTelMed(int telMed) {
      this.telMed.set(telMed);
    }
    
    public String getAdresseMed() {
      return adresseMed.get();
    }
    public StringProperty adresseMedProperty() {
      return adresseMed;
    }
    public void setAdresseMed(String adresseMed) {
      this.adresseMed.set(adresseMed);
    }
}
