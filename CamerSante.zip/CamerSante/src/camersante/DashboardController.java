/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package camersante;

import static camersante.CamerSante.con;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.AreaChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author Administrateur
 */
public class DashboardController implements Initializable{

    @FXML
    private AnchorPane accueil_Patient;

    @FXML
    private AnchorPane accueil_RDV;

    @FXML
    private AreaChart<?, ?> accueil_donnees;

    @FXML
    private AnchorPane accueil_medecin;

    @FXML
    private TextField adresse_Medecin;

    @FXML
    private TextField adresse_Patient;

    @FXML
    private TableColumn<Medecin, String> adresse_tb_Medecin;

    @FXML
    private TableColumn<Patient, String> adresse_tb_Patient;
    
    @FXML
    private TextField age_Patient;

    @FXML
    private TableColumn<Patient, Integer> age_tb_Patient;

    @FXML
    private Button ajouter_Medecin;

    @FXML
    private Button ajouter_Patient;

    @FXML
    private AnchorPane anchorPane_Accueil;

    @FXML
    private AnchorPane anchorPane_Medecin;

    @FXML
    private AnchorPane anchorPane_Patient;

    @FXML
    private Button btn_Accueil;

    @FXML
    private Button btn_Medecin;

    @FXML
    private Button btn_Patient;
    
    @FXML
    private Button clear_Patient;

    @FXML
    private Button close_red;
    
    @FXML
    private Button deconnexion_btn;

    @FXML
    private Button delete_Medecin;

    @FXML
    private Button delete_Patient;

    @FXML
    private Button edit_Patient;

    @FXML
    private Button edite_Medecin;

    @FXML
    private TextField email_Medecin;

    @FXML
    private TextField email_Patient;

    @FXML
    private TableColumn<Medecin, String> email_tb_Medecin;

    @FXML
    private TableColumn<Patient, String> email_tb_Patient;
    
    @FXML
    private ComboBox<?> genre_Patient;

    @FXML
    private TableColumn<Patient, String> genre_tb_Patient;

    @FXML
    private TextField id_Medecin;

    @FXML
    private TextField id_Patient;

    @FXML
    private TableColumn<Medecin, Integer> id_tb_Medecin;

    @FXML
    private TableColumn<Patient, Integer> id_tb_Patient;

    @FXML
    private AnchorPane main_form;

    @FXML
    private Button minimize_btn;
    
    @FXML
    private Label nbreMedecin;

    @FXML
    private Label nbrePatient;

    @FXML
    private Label nbreRdv;
    
     @FXML
    private Label nbreRdvAnnule;

    @FXML
    private Label nbreRdvAttente;

    @FXML
    private Label nbreRdvEffectue;

    @FXML
    private Label nbreRdvRejete;

    @FXML
    private TextField nom_Medecin;

    @FXML
    private TextField nom_Patient;

    @FXML
    private TableColumn<Medecin, String> nom_tb_Medecin;

    @FXML
    private TableColumn<Patient, String> nom_tb_Patient;

    @FXML
    private TextField prenom_Medecin;

    @FXML
    private TextField prenom_Patient;

    @FXML
    private TableColumn<Medecin, String> prenom_tb_Medecin;

    @FXML
    private TableColumn<Patient, String> prenom_tb_Patient;

    @FXML
    private TextField search_Medecin;

    @FXML
    private TextField search_Patient;

    @FXML
    private ImageView search_btn_Medecin;

    @FXML
    private ImageView search_btn_Patient;

    @FXML
    private ComboBox<String> specialite_Medecin;

    @FXML
    private TableColumn<Medecin, String> specialite_tb_Medecin;

    @FXML
    private TableView<Medecin> table_Medecin;

    @FXML
    private TableView<Patient> table_Patient;

    @FXML
    private TextField tel_Medecin;

    @FXML
    private TextField tel_Patient;

    @FXML
    private TableColumn<Medecin, Integer> tel_tb_Medecin;

    @FXML
    private TableColumn<Patient, Integer> tel_tb_Patient;

    @FXML
    private Label usernameAffiche;
    
    //Outils de la Base de Donnees
    private Connection connect = null;
    private PreparedStatement prepare;
    private Statement statement;
    private ResultSet result;
    private String[] specialiteList = {
        "Anesthésiologie","Cardiologie","Chirugie générale","Chirugie spécialisé", "Dentiste", "Dermatologie",
        "Diabète & endocrinologie","Gastroentérologie","Gynéco-Obstétrique","Gynecologie","Hématologie",
        "Maladies infectueuses/VIH","Médecine du travail","Médecine générale","Médecine interne",
        "Médecine physique","Néphrologie","Neurologie","Oncologie","Orthopedie", "ORL", 
        "Pédiatrie","Pneumologie","Psychiatrie","Radiologie", "Rhumatologie",
        "Soins intensifs", "Urologie", "Autre"};
    
    private String[] genreList = {"Masculin", "Féminin", "Autre", "m'abstenir"};//utilisee pour ajouter des elements a la liste de specialite
    
    private void compterMedecin(){
        
        String sql = "SELECT COUNT(id) FROM medecin_table";
        
        connect = Database.connectDb();
        int counter = 0;
        
        try{
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();
            
            while(result.next()){
                counter = result.getInt("COUNT(id)");
            }
            
            nbreMedecin.setText(String.valueOf(counter));
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
    
    
    //XXXXXXXXXXXXXXXXXXXXXXXXX___BLOC DE MEDECIN___XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
    //inserer un medecin au tanleau
    public void addMedecinAdd(){
        String sql = "insert into medecin_table (id, nom, prenom, specialite, email, telephone, adresse) VALUES(?,?,?,?,?,?,?)";
        
        connect = Database.connectDb();
        
        try{
            Alert alert;
            //prepare = connect.prepareStatement(sql);
            
            if(id_Medecin.getText().isEmpty() 
                    || nom_Medecin.getText().isEmpty() 
                    || prenom_Medecin.getText().isEmpty() 
                    || specialite_Medecin.getSelectionModel().getSelectedItem() == null 
                    || email_Medecin.getText().isEmpty() 
                    || tel_Medecin.getText().isEmpty() 
                    || adresse_Medecin.getText().isEmpty()){
                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Message d'erreur");
                alert.setHeaderText(null);
                alert.setContentText("Veuillez remplir tous les champs");
                alert.showAndWait();
            }else{
                
                String checkData = ("SELECT id FROM medecin_table WHERE id = '"
                        +id_Medecin.getText()+"'");
                
                statement = connect.createStatement();
                result = statement.executeQuery(checkData);
                
                if(result.next()){
                    alert = new Alert(AlertType.ERROR);
                    alert.setTitle("Message d'erreur");
                    alert.setHeaderText(null);
                    alert.setContentText("Id: " + id_Medecin.getText() 
                            + " est déjà utilisé par un autre médecin." 
                            + "\n" 
                            + "Veuillez entrer un autre identifiant.");
                    alert.showAndWait();
                }else{
                 
                    prepare = (PreparedStatement) connect.prepareStatement(sql);
                    prepare.setString(1, id_Medecin.getText());
                    prepare.setString(2, nom_Medecin.getText());
                    prepare.setString(3, prenom_Medecin.getText());
                    prepare.setString(4, (String) specialite_Medecin.getSelectionModel().getSelectedItem().toString());
                    prepare.setString(5, email_Medecin.getText());
                    prepare.setString(6, tel_Medecin.getText());
                    prepare.setString(7, adresse_Medecin.getText());
                    
                    prepare.executeUpdate();
                    
                    //affiche le message 'Ajoutez'
                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information");
                    alert.setHeaderText(null);
                    alert.setContentText("Ajouté avec success !");
                    alert.showAndWait();
                    
                    //mettre a jour les champs
                    addMedecinShowListData();
                    
                    connect.close();
                    prepare.close();
                    
                    //liberer les champs de saisie
                    clearMedecin();
                    compterMedecin();
                }
            }
            
           
        }catch(Exception e){
            System.out.println("____________________________________________"+"\n");
            e.printStackTrace();
            System.out.println(".........Probleme de connexion.........");
        }
    }
    
    //Methode permettant d'ajouter un medecin a la liste des medecins dans la BD
    public ObservableList<Medecin> addMedecinListData(){
        
        ObservableList<Medecin> listData = FXCollections.observableArrayList();
        
        String sql = "SELECT * FROM medecin_table";
        
        //connecter le tableau a la base de donnees
        connect = Database.connectDb();
        
        try{
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();
            Medecin MedecinD;
            
            while(result.next()){
                MedecinD = new Medecin(result.getInt("id")
                        , result.getString("nom")
                        , result.getString("prenom")
                        , result.getString("specialite")
                        , result.getString("email")
                        , result.getInt("telephone")
                        , result.getString("adresse"));
                
                //ajouter MedecinD a la liste des medecins
                listData.add(MedecinD);
            }
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("***********Echec addList************");
        }
        
        return listData;
    }
    
    //afficher un medecin dans le tableau de gauche 
    ObservableList<Medecin> addMedecinList = FXCollections.observableArrayList();
    public void addMedecinShowListData(){
        addMedecinList = addMedecinListData();
        
        //l'identifiant de chaque colonne du tableau table_Medecin prend la valeur 
        //comprise dans chaque colonne de la medecin_table
        
        id_tb_Medecin.setCellValueFactory(new PropertyValueFactory<Medecin, Integer>("idMed"));
        nom_tb_Medecin.setCellValueFactory(new PropertyValueFactory<Medecin, String>("nomMed"));
        prenom_tb_Medecin.setCellValueFactory(new PropertyValueFactory<Medecin, String>("prenomMed"));
        specialite_tb_Medecin.setCellValueFactory(new PropertyValueFactory<Medecin, String>("specialiteMed"));                  
        email_tb_Medecin.setCellValueFactory(new PropertyValueFactory<Medecin, String>("emailMed"));
        tel_tb_Medecin.setCellValueFactory(new PropertyValueFactory<Medecin, Integer>("telMed"));
        adresse_tb_Medecin.setCellValueFactory(new PropertyValueFactory<Medecin, String>("adresseMed"));
        
        table_Medecin.setItems(addMedecinList);
        
    }
    
    //Ajouter le medecin selectionné aux champs de saisie
    public void addMedecinSelect(){
        
        try{
            Medecin MedecinD = (Medecin) table_Medecin.getSelectionModel().getSelectedItem();
        
            int num;

            num = table_Medecin.getSelectionModel().getFocusedIndex();

            //System.out.println(num);

            if((num -1) < -1){return;}

            id_Medecin.setText(String.valueOf(MedecinD.getIdMed()));
            nom_Medecin.setText(String.valueOf(MedecinD.getNomMed()));
            prenom_Medecin.setText(String.valueOf(MedecinD.getPrenomMed()));
            specialite_Medecin.setAccessibleText(MedecinD.getSpecialiteMed());
            email_Medecin.setText(String.valueOf(MedecinD.getEmailMed()));
            tel_Medecin.setText(String.valueOf(MedecinD.getTelMed()));
            adresse_Medecin.setText(String.valueOf(MedecinD.getAdresseMed()));
            
        
        }catch(Exception e){
            System.out.println("****Probleme de selection****");
            e.printStackTrace();
        }
    }
    
    //__________________Nettoyer les champs de saisie________________
    
    public void clearMedecin(){
        id_Medecin.setText("");
        nom_Medecin.setText("");
        prenom_Medecin.setText("");
        specialite_Medecin.getSelectionModel().clearSelection();
        email_Medecin.setText("");
        tel_Medecin.setText("");
        adresse_Medecin.setText("");
    }
    
    //______________Methode d'ajout de specialite dans la liste de sppecialite__________
    
    public void addMedecinSpecialiteList(){
        List<String> listS = new ArrayList<>();
        
        for(String Data : specialiteList){
            listS.add(Data);
        }
        
        ObservableList listD = FXCollections.observableArrayList(listS);
        specialite_Medecin.setItems(listD);
    } 
    
    public void updateMedecin(){
        
        String sql = "UPDATE medecin_table SET nom = '"
                +nom_Medecin.getText()+"', prenom = '"
                +prenom_Medecin.getText()+"', specialite = '"
                +specialite_Medecin.getSelectionModel().getSelectedItem()+"', email = '"
                +email_Medecin.getText()+"', telephone = '"
                +tel_Medecin.getText()+"', adresse = '"
                +adresse_Medecin.getText()+"' WHERE id = '"
                +id_Medecin.getText()+"'";
        
        connect = Database.connectDb();
        
        try{
            Alert alert;
            //prepare = connect.prepareStatement(sql);
            
            if(id_Medecin.getText().isEmpty() 
                    || nom_Medecin.getText().isEmpty() 
                    || prenom_Medecin.getText().isEmpty() 
                    || specialite_Medecin.getSelectionModel().getSelectedItem() == null 
                    || email_Medecin.getText().isEmpty() 
                    || tel_Medecin.getText().isEmpty() 
                    || adresse_Medecin.getText().isEmpty()){
                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Message d'erreur");
                alert.setHeaderText(null);
                alert.setContentText("Veuillez remplir tous les champs");
                alert.showAndWait();
            }else{
                alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Attention");
                alert.setHeaderText(null);
                alert.setContentText("Souhaitez-vous vraiment mettre à jour le medecin d'ID : "+id_Medecin.getText() + " ?");
                Optional<ButtonType> option = alert.showAndWait();
                
                if(option.get().equals(ButtonType.OK)){
                    statement = connect.createStatement();
                    statement.executeUpdate(sql);
                    
                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information");
                    alert.setHeaderText(null);
                    alert.setContentText("Mise à jour effectuée avec success !");
                    alert.showAndWait();
                    
                    //mettre a jour les champs
                    addMedecinShowListData();
                    connect.close();
                    
                    //liberer les champs de saisie
                    clearMedecin();
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void deleteMedecin(){
        String sql = "DELETE FROM medecin_table WHERE id = '"+id_Medecin.getText()+"'";
        
        connect = Database.connectDb();
        
        try{
            Alert alert;
            //prepare = connect.prepareStatement(sql);
            
            if(id_Medecin.getText().isEmpty() 
                    || nom_Medecin.getText().isEmpty() 
                    || prenom_Medecin.getText().isEmpty() 
                    || email_Medecin.getText().isEmpty() 
                    || tel_Medecin.getText().isEmpty() 
                    || adresse_Medecin.getText().isEmpty()){
                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Message d'erreur");
                alert.setHeaderText(null);
                alert.setContentText("Veuillez remplir tous les champs");
                alert.showAndWait();
            }else{
                alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Attention");
                alert.setHeaderText(null);
                alert.setContentText("Souhaitez-vous vraiment supprimer le medecin d'ID : "+id_Medecin.getText() + " ?");
                Optional<ButtonType> option = alert.showAndWait();
                
                if(option.get().equals(ButtonType.OK)){
                    statement = connect.createStatement();
                    statement.executeUpdate(sql);
                    
                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information");
                    alert.setHeaderText(null);
                    alert.setContentText("Suppression effectuée avec success !");
                    alert.showAndWait();
                    
                    //mettre a jour les champs
                    addMedecinShowListData();
                    connect.close();
                    
                    //liberer les champs de saisie
                    clearMedecin();
                    compterMedecin();
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void searchMedecin(){
        FilteredList<Medecin> filter = new FilteredList<>(addMedecinList, e-> true);
        
        search_Medecin.textProperty().addListener((Observable, oldValue, newValue)->{
            
            filter.setPredicate(predicateMedecin ->{
                
                if(newValue == null || newValue.isEmpty()){
                    return false;
                }
                String searchKey = newValue;
                
                if(predicateMedecin.idMedProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicateMedecin.nomMedProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicateMedecin.prenomMedProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicateMedecin.specialiteMedProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicateMedecin.emailMedProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicateMedecin.telMedProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicateMedecin.adresseMedProperty().toString().contains(searchKey)){
                    return true;
                }else{return false;}
            });
        });
        
        SortedList<Medecin> sortlist = new SortedList<>(filter);
        
        sortlist.comparatorProperty().bind(table_Medecin.comparatorProperty());
        table_Medecin.setItems(sortlist);
    }
    
    //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
    
    //XXXXXXXXXXXXXXXXXXXXXXXX___BLOC D'ACCUEIL___XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
    
    public void accueilDonnees(){
        
        accueil_donnees.getData().clear();
        
        //String sql = "SELECT date, SUM(effectue) FROM rdv_table GROUP BY date TIMESTAMP(date) ASC LIMIT 9";
        String sql = "SELECT date, MAX(id_rdv) FROM rdv_table GROUP BY date TIMESTAMP(date) ASC LIMIT 9";
        connect = Database.connectDb();
        
        try{
            XYChart.Series chart = new XYChart.Series();
            
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();
            
            while(result.next()){
                chart.getData().add(new XYChart.Data(result.getString(1), result.getString(2)));
            }
            accueil_donnees.getData().add(chart);
            result.close();
        }catch(Exception e){e.printStackTrace();}
    }
    
    public void afficherMonNom(){
        String user = GetterDonnees.username;
        
        //usernameAffiche.setText(user.substring(0, 1).toLowerCase() + user.substring(1));
        usernameAffiche.setText(String.valueOf(user));
    }
    private void compterRdv(){
        
        String sql = "SELECT COUNT(id_rdv) FROM rdv_table";
        
        connect = Database.connectDb();
        int counter = 0;
        
        try{
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();
            
            while(result.next()){
                counter = result.getInt("COUNT(id_rdv)");
            }
            
            nbreRdv.setText(String.valueOf(counter));
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
    private void compterRdvAttente(){
        
        String sql = "SELECT COUNT(id_rdv) FROM rdv_table WHERE valide LIKE 'Pas encore'";
        
        connect = Database.connectDb();
        int counter = 0;
        
        try{
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();
            
            while(result.next()){
                counter = result.getInt("COUNT(id_rdv)");
            }
            
            nbreRdvAttente.setText(String.valueOf(counter));
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
    private void compterRdvEffectue(){
        
        String sql = "SELECT COUNT(id_rdv) FROM rdv_table WHERE effectue LIKE 'Oui'";
        
        connect = Database.connectDb();
        int counter = 0;
        
        try{
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();
            
            while(result.next()){
                counter = result.getInt("COUNT(id_rdv)");
            }
            
            nbreRdvEffectue.setText(String.valueOf(counter));
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
    private void compterRdvAnnule(){
        
        String sql = "SELECT COUNT(id_rdv) FROM rdv_table WHERE ((valide  LIKE 'Annulé') OR (effectue  LIKE 'Annulé'))";
        
        connect = Database.connectDb();
        int counter = 0;
        
        try{
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();
            
            while(result.next()){
                counter = result.getInt("COUNT(id_rdv)");
            }
            
            nbreRdvAnnule.setText(String.valueOf(counter));
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
    private void compterRdvRejete(){
        
        String sql = "SELECT COUNT(id_rdv) FROM rdv_table WHERE valide LIKE 'Rejeté'";
        
        connect = Database.connectDb();
        int counter = 0;
        
        try{
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();
            
            while(result.next()){
                counter = result.getInt("COUNT(id_rdv)");
            }
            
            nbreRdvRejete.setText(String.valueOf(counter));
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
    
    public void voirRdv() throws IOException{
        //pour lier l'interface d'accueil Admmin
                    Parent root = FXMLLoader.load(getClass().getResource("PageRdv.fxml"));
                    Stage stage = new Stage();
                    Scene scene = new Scene(root);
                    //le rendre invisible
                    stage.initStyle(StageStyle.TRANSPARENT);
                    
                    stage.setScene(scene);
                    stage.show();
    }
    
    //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
    
    
    
    //XXXXXXXXXXXXXXXXXXXXXXXX___BLOC DE PATIENT___XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
    private void compterPatient(){
        
        String sql = "SELECT COUNT(id) FROM patient_table";
        
        connect = Database.connectDb();
        int counter = 0;
        
        try{
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();
            
            while(result.next()){
                counter = result.getInt("COUNT(id)");
            }
            
            nbrePatient.setText(String.valueOf(counter));
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
    
    //ajouter un patient a la BD dans la table patient_table
    public void addPatientAdd(){
        String sql = "INSERT into patient_table (id, nom, prenom, email, genre, age, telephone, adresse) VALUES(?,?,?,?,?,?,?,?)";
        
        connect = Database.connectDb();
        
        try{
            Alert alert;
            //prepare = connect.prepareStatement(sql);
            
            if(id_Patient.getText().isEmpty() 
                    || nom_Patient.getText().isEmpty() 
                    || prenom_Patient.getText().isEmpty() 
                    || genre_Patient.getSelectionModel().getSelectedItem() == null 
                    || email_Patient.getText().isEmpty() 
                    || age_Patient.getText().isEmpty()
                    || tel_Patient.getText().isEmpty()
                    || adresse_Patient.getText().isEmpty()){
                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Message d'erreur");
                alert.setHeaderText(null);
                alert.setContentText("Veuillez remplir tous les champs");
                alert.showAndWait();
            }else{
                
                String checkData = ("SELECT id FROM patient_table WHERE id = '"
                        +id_Patient.getText()+"'");
                
                statement = connect.createStatement();
                result = statement.executeQuery(checkData);
                
                if(result.next()){
                    alert = new Alert(AlertType.ERROR);
                    alert.setTitle("Message d'erreur");
                    alert.setHeaderText(null);
                    alert.setContentText("Id: " + id_Patient.getText() 
                            + " est déjà utilisé par un autre médecin." 
                            + "\n" 
                            + "Veuillez entrer un autre identifiant.");
                    alert.showAndWait();
                }else{
                 
                    prepare = (PreparedStatement) connect.prepareStatement(sql);
                    
                    prepare.setString(1, id_Patient.getText());
                    prepare.setString(2, nom_Patient.getText());
                    prepare.setString(3, prenom_Patient.getText());
                    prepare.setString(4, email_Patient.getText());
                    prepare.setString(5, (String) genre_Patient.getSelectionModel().getSelectedItem().toString());
                    prepare.setString(6, age_Patient.getText());
                    prepare.setString(7, tel_Patient.getText());
                    prepare.setString(8, adresse_Patient.getText());
                    
                    prepare.executeUpdate();
                    
                    //affiche le message 'Ajoutez'
                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information");
                    alert.setHeaderText(null);
                    alert.setContentText("Ajouté avec success !");
                    alert.showAndWait();
                    
                    //mettre a jour les champs
                    addPatientShowListData();
                    
                    //connect.close();
                    //prepare.close();
                    
                    //liberer les champs de saisie
                    clearPatient();
                    compterPatient();
                }
            }
            
           
        }catch(Exception e){
            System.out.println("____________________________________________"+"\n");
            e.printStackTrace();
            System.out.println(".........Probleme de connexion.........");
        }
    }
    
    //Methode permettant d'ajouter un medecin a la liste des medecins dans la BD
    public ObservableList<Patient> addPatientListData(){
        
        ObservableList<Patient> listData = FXCollections.observableArrayList();
        
        String sql = "SELECT * FROM patient_table";
        
        //connecter le tableau a la base de donnees
        connect = Database.connectDb();
        
        try{
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();
            Patient PatientD;
            
            while(result.next()){
                PatientD = new Patient(result.getInt("id")
                        , result.getString("nom")
                        , result.getString("prenom")
                        , result.getString("email")
                        , result.getString("genre")
                        , result.getInt("age")
                        , result.getInt("telephone")
                        , result.getString("adresse"));
                
                //ajouter MedecinD a la liste des medecins
                listData.add(PatientD);
                
                //result.close();
                //prepare.close();
            }
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("***********Echec addList************");
        }
        
        return listData;
    }
    
    //afficher un medecin dans le tableau de gauche 
    ObservableList<Patient> addPatientList = FXCollections.observableArrayList();
    public void addPatientShowListData(){
        addPatientList = addPatientListData();
        
        //l'identifiant de chaque colonne du tableau table_Medecin prend la valeur 
        //comprise dans chaque colonne de la medecin_table 
        
        id_tb_Patient.setCellValueFactory(new PropertyValueFactory<Patient, Integer>("idPat"));
        nom_tb_Patient.setCellValueFactory(new PropertyValueFactory<Patient, String>("nomPat"));
        prenom_tb_Patient.setCellValueFactory(new PropertyValueFactory<Patient, String>("prenomPat"));
        email_tb_Patient.setCellValueFactory(new PropertyValueFactory<Patient, String>("emailPat"));
        genre_tb_Patient.setCellValueFactory(new PropertyValueFactory<Patient, String>("genrePat"));                  
        age_tb_Patient.setCellValueFactory(new PropertyValueFactory<Patient, Integer>("agePat"));
        tel_tb_Patient.setCellValueFactory(new PropertyValueFactory<Patient, Integer>("telPat"));
        adresse_tb_Patient.setCellValueFactory(new PropertyValueFactory<Patient, String>("adressePat"));
        
        table_Patient.setItems(addPatientList);
        
    }
    
    //Ajouter le medecin selectionné aux champs de saisie
    public void addPatientSelect(){
        
        try{
            Patient PatientD = (Patient) table_Patient.getSelectionModel().getSelectedItem();
        
            int num;

            num = table_Patient.getSelectionModel().getFocusedIndex();

            System.out.println(num);

            if((num -1) < -1){return;}

            id_Patient.setText(String.valueOf(PatientD.getIdPat()));
            nom_Patient.setText(String.valueOf(PatientD.getNomPat()));
            prenom_Patient.setText(String.valueOf(PatientD.getPrenomPat()));
            email_Patient.setText(String.valueOf(PatientD.getEmailPat()));
            genre_Patient.setAccessibleText(PatientD.getGenrePat());
            age_Patient.setText(String.valueOf(PatientD.getAgePat()));
            tel_Patient.setText(String.valueOf(PatientD.getTelPat()));
            adresse_Patient.setText(String.valueOf(PatientD.getAdressePat()));
            
        
        }catch(Exception e){
            System.out.println("****Probleme de selection****");
            e.printStackTrace();
        }
    }
    
    //__________________Nettoyer les champs de saisie________________
    
    public void clearPatient(){
        id_Patient.setText("");
        nom_Patient.setText("");
        prenom_Patient.setText("");
        email_Patient.setText("");
        genre_Patient.getSelectionModel().clearSelection();
        age_Patient.setText("");
        tel_Patient.setText("");
        adresse_Patient.setText("");
    }
    
    //______________Methode d'ajout de specialite dans la liste de sppecialite__________
    
    public void addPatientGenreList(){
        List<String> listS = new ArrayList<>();
        
        for(String Data : genreList){
            listS.add(Data);
        }
        
        ObservableList listD = FXCollections.observableArrayList(listS);
        genre_Patient.setItems(listD);
    } 
    
    public void updatePatient(){
        
        String sql = "UPDATE patient_table SET nom = '"
                +nom_Patient.getText()+"', prenom = '"
                +prenom_Patient.getText()+"', email = '"
                +email_Patient.getText()+"', genre = '"
                +genre_Patient.getSelectionModel().getSelectedItem()+"', age = '"
                +age_Patient.getText()+"', telephone = '"
                +tel_Patient.getText()+"', adresse = '"
                +adresse_Patient.getText()+"' WHERE id = '"
                +id_Patient.getText()+"'";
        
        connect = Database.connectDb();
        
        try{
            Alert alert;
            //prepare = connect.prepareStatement(sql);
            
            if(id_Patient.getText().isEmpty() 
                    || nom_Patient.getText().isEmpty() 
                    || prenom_Patient.getText().isEmpty() 
                    || email_Patient.getText().isEmpty()
                    || genre_Patient.getSelectionModel().getSelectedItem() == null 
                    || age_Patient.getText().isEmpty() 
                    || tel_Patient.getText().isEmpty() 
                    || adresse_Patient.getText().isEmpty()){
                
                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Message d'erreur");
                alert.setHeaderText(null);
                alert.setContentText("Veuillez remplir tous les champs");
                alert.showAndWait();
            }else{
                alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Attention");
                alert.setHeaderText(null);
                alert.setContentText("Souhaitez-vous vraiment mettre à jour le medecin d'ID : "+id_Patient.getText() + " ?");
                Optional<ButtonType> option = alert.showAndWait();
                
                if(option.get().equals(ButtonType.OK)){
                    statement = connect.createStatement();
                    statement.executeUpdate(sql);
                    
                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information");
                    alert.setHeaderText(null);
                    alert.setContentText("Mise à jour effectuée avec success !");
                    alert.showAndWait();
                    
                    //mettre a jour les champs
                    addPatientShowListData();
                    
                    //liberer les champs de saisie
                    clearPatient();
                }
                connect.close();
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void deletePatient(){
        String sql = "DELETE FROM patient_table WHERE id = '"+id_Patient.getText()+"'";
        
        connect = Database.connectDb();
        
        try{
            Alert alert;
            //prepare = connect.prepareStatement(sql);
            
            if(id_Patient.getText().isEmpty() 
                    || nom_Patient.getText().isEmpty() 
                    || prenom_Patient.getText().isEmpty() 
                    || email_Patient.getText().isEmpty() 
                    || age_Patient.getText().isEmpty()
                    || tel_Patient.getText().isEmpty() 
                    || adresse_Patient.getText().isEmpty()){
                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Message d'erreur");
                alert.setHeaderText(null);
                alert.setContentText("Veuillez remplir tous les champs");
                alert.showAndWait();
            }else{
                alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Attention");
                alert.setHeaderText(null);
                alert.setContentText("Souhaitez-vous vraiment supprimer le patient d'ID : "+id_Patient.getText() + " ?");
                Optional<ButtonType> option = alert.showAndWait();
                
                if(option.get().equals(ButtonType.OK)){
                    statement = connect.createStatement();
                    statement.executeUpdate(sql);
                    
                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information");
                    alert.setHeaderText(null);
                    alert.setContentText("Suppression effectuée avec success !");
                    alert.showAndWait();
                    
                    //mettre a jour les champs
                    addPatientShowListData();
                    
                    
                    //liberer les champs de saisie
                    clearPatient();
                    compterPatient();
                }
                connect.close();
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void searchPatient(){
        FilteredList<Patient> filter = new FilteredList<>(addPatientList, e-> true);
        
        search_Patient.textProperty().addListener((Observable, oldValue, newValue)->{
            
            filter.setPredicate(predicatePatient ->{
                
                if(newValue == null || newValue.isEmpty()){
                    return false;
                }
                String searchKey = newValue;
                
                if(predicatePatient.idPatProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicatePatient.nomPatProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicatePatient.prenomPatProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicatePatient.genrePatProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicatePatient.agePatProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicatePatient.emailPatProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicatePatient.telPatProperty().toString().contains(searchKey)){
                    return true;
                }else if(predicatePatient.adressePatProperty().toString().contains(searchKey)){
                    return true;
                }else{return false;}
            });
        });
        
        SortedList<Patient> sortlist = new SortedList<>(filter);
        
        sortlist.comparatorProperty().bind(table_Patient.comparatorProperty());
        table_Patient.setItems(sortlist);
    }
    
    //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
    
    //XXXXXXXXXXXXXXX___BLOC DE FENETRE ET NAVIGATION___XXXXXXXXXXXXXXXXXXXXXXXXX
    
    //Afficher les differentes interfaces apres appuis sur un bouton
    
    public void defaultBtn(){
        btn_Accueil.setStyle("-fx-background-color: #2280dd;");
        anchorPane_Accueil.setVisible(true);
        anchorPane_Medecin.setVisible(false);
        anchorPane_Patient.setVisible(false);
    }   
    public void switchForm(ActionEvent event){
        if(event.getSource() == btn_Accueil){
            anchorPane_Accueil.setVisible(true);
            anchorPane_Medecin.setVisible(false);
            anchorPane_Patient.setVisible(false);
            
            btn_Accueil.setStyle("-fx-background-color: #2280dd;");
            btn_Medecin.setStyle("-fx-background-color: transparent;");
            btn_Patient.setStyle("-fx-background-color: transparent;");
            
            compterRdv();
            compterRdvEffectue();
            compterRdvAttente();
            compterRdvAnnule();
            compterRdvRejete();
            compterPatient();
            compterMedecin();
                   
            
        }else if(event.getSource() == btn_Medecin){
            anchorPane_Accueil.setVisible(false);
            anchorPane_Medecin.setVisible(true);
            anchorPane_Patient.setVisible(false);   
            
            btn_Medecin.setStyle("-fx-background-color: #2280dd;");
            btn_Accueil.setStyle("-fx-background-color: transparent;");
            btn_Patient.setStyle("-fx-background-color: transparent;");
            
            // Actualiser la liste dans table_Medecin
            addMedecinShowListData();
            addMedecinSpecialiteList();
            searchMedecin();
            
        }else if(event.getSource() == btn_Patient){
            anchorPane_Accueil.setVisible(false);
            anchorPane_Medecin.setVisible(false);
            anchorPane_Patient.setVisible(true);
            
            btn_Patient.setStyle("-fx-background-color: #2280dd;");
            btn_Accueil.setStyle("-fx-background-color: transparent;");
            btn_Medecin.setStyle("-fx-background-color: transparent;");
            
            addPatientShowListData();
            addPatientGenreList();
            searchPatient();
        }
    }
    
    private double x = 0;
    private double y = 0;
    
    public void logout(){
        try{
            Alert alert = new Alert(AlertType.CONFIRMATION);
            alert.setTitle("Message d'erreur");
            alert.setHeaderText(null);
            alert.setContentText("Voulez-vous vraiment vous déconnecter ?");
            
            Optional<ButtonType> option = alert.showAndWait();
            
            if(option.get().equals(ButtonType.OK)){
                
                //masquer la fenetre Admin
                deconnexion_btn.getScene().getWindow().hide();
                
                Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
                Stage stage = new Stage();
                Scene scene = new Scene(root);
                
                //sous pression de la souris
                root.setOnMousePressed((MouseEvent event) ->{

                    x = event.getSceneX(); 
                    y = event.getSceneY();
                });

                //sur glissement de la souris
                root.setOnMouseDragged((MouseEvent event) ->{

                    stage.setX(event.getSceneX() - x);
                    stage.setY(event.getSceneY() - y);
                });
                //le rendre invisible
                stage.initStyle(StageStyle.TRANSPARENT);
                    
                stage.setScene(scene);
                stage.show();
            }
        }catch(Exception e){e.printStackTrace();}
    }
    
    public void close(){
        System.exit(0);
    }
    
    public void minimize(){
        Stage stage = (Stage)main_form.getScene().getWindow();
        stage.setIconified(true);
    }
    
    //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
 
    //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
    
    
    
    
  
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        afficherMonNom();
        defaultBtn();
        
        compterPatient();
        addPatientListData();
        addPatientShowListData();
        addPatientGenreList();
        
        addMedecinListData();
        addMedecinShowListData();
        addMedecinSpecialiteList();
        compterMedecin();
        
        compterRdv();
        compterRdvEffectue();
        compterRdvAttente();
        compterRdvAnnule();
        compterRdvRejete();
        
        //accueilDonnees();
    }
    
}
