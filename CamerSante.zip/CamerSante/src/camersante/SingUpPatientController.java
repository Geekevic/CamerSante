/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camersante;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author Administrateur
 */
public class SingUpPatientController implements Initializable {

    @FXML
    private AnchorPane close_rose;

    @FXML
    private Label connectezVous;

    @FXML
    private Button enregistrerBtn;

    @FXML
    private AnchorPane main_form;

    @FXML
    private PasswordField password1;

    @FXML
    private PasswordField password2;
    
    @FXML
    private Text textError;

    @FXML
    private ComboBox<?> textView_Genre;

    @FXML
    private TextField textView_adresse;

    @FXML   
    private TextField textView_age;

    @FXML
    private TextField textView_email;

    @FXML
    private TextField textView_nom;

    @FXML
    private TextField textView_prenom;

    @FXML
    private TextField textView_telephone;

    @FXML
    void close(MouseEvent event) {
        System.exit(0);
    }
    
//    @FXML
//    void enregistrerPatient(ActionEvent event) {
//
//    }

    @FXML
    void login(MouseEvent event) throws IOException{

        connectezVous.getScene().getWindow().hide();
                    
                    //pour lier l'interface d'accueil Admmin
                    Parent root = FXMLLoader.load(getClass().getResource("loginPatient.fxml"));
                    Stage stage = new Stage();
                    Scene scene = new Scene(root);
                    //le rendre invisible
                    stage.initStyle(StageStyle.TRANSPARENT);
                    
                    stage.setScene(scene);
                    stage.show();
    }
    
    private Connection connect = null;
    private PreparedStatement prepare;
    private Statement statement;
    private ResultSet result;
    private String[] genreList = {"Masculin", "Féminin", "Autre", "m'abstenir"};//utilisee pour ajouter des elements a la liste de specialite
    /**
     * Initializes the controller class.
     */
    public void goToNextPage() throws IOException{
        enregistrerBtn.getScene().getWindow().hide();
                    
                    //pour lier l'interface d'accueil Admmin
                    Parent root = FXMLLoader.load(getClass().getResource("PagePatient.fxml"));
                    Stage stage = new Stage();
                    Scene scene = new Scene(root);
                    stage.initStyle(StageStyle.TRANSPARENT);
                    
                    stage.setScene(scene);
                    stage.show();
    }
    public void enregistrerPatient() throws IOException{
        String sql = "insert into patient_table (nom, prenom, email, genre, age, telephone, adresse, password) VALUES(?,?,?,?,?,?,?,?)";
        
        connect = Database.connectDb();
        
        try{
            Alert alert;
            //prepare = connect.prepareStatement(sql);
            
            if(textView_nom.getText().isEmpty() 
                    || textView_prenom.getText().isEmpty() 
                    || password1.getText().isEmpty()
                    || password2.getText().isEmpty()
                    || textView_Genre.getSelectionModel().getSelectedItem() == null 
                    || textView_age.getText().isEmpty() 
                    || textView_email.getText().isEmpty()
                    || textView_telephone.getText().isEmpty() 
                    || textView_adresse.getText().isEmpty()){
               
                
                
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Message d'erreur");
                alert.setHeaderText(null);
                alert.setContentText("Veuillez remplir tous les champs");
                alert.showAndWait();
                
            }else{
                
                if(password1.getText().toString().equals(password2.getText().toString())){
                    String checkData = ("SELECT email FROM patient_table WHERE email = '"
                        +textView_email.getText()+"'");
                
                    statement = connect.createStatement();
                    result = statement.executeQuery(checkData);
                
                    if(result.next()){
                        alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Message d'erreur");
                        alert.setHeaderText(null);
                        alert.setContentText("L'email: " + textView_email.getText() 
                                + " est déjà utilisé par un autre patient." 
                                + "\n" 
                                + "Veuillez entrer un autre email.");
                        alert.showAndWait();
                    }else{

                        

                        prepare = (PreparedStatement) connect.prepareStatement(sql);
                        prepare.setString(1, textView_nom.getText());
                        prepare.setString(2, textView_prenom.getText());
                        prepare.setString(3, textView_email.getText());
                        prepare.setString(4, (String) textView_Genre.getSelectionModel().getSelectedItem().toString());
                        prepare.setString(5, textView_age.getText());
                        prepare.setString(6, textView_telephone.getText());
                        prepare.setString(7, textView_adresse.getText());
                        prepare.setString(8, password1.getText());

                        prepare.executeUpdate();
                        
                        connect.close();

                        //***********************recuper l'id d'un email****************
                        String sql2 = "SELECT id FROM patient_table WHERE email = '"+textView_email.getText()+"'";
                        Connection connect2;
                        connect2 = Database.connectDb();
                        PreparedStatement prepare2 = connect2.prepareStatement(sql2);
                        ResultSet result2;


                        try{
                            result2 = prepare2.executeQuery();
                            if(result2.next()){
                                int i = result2.getInt("id");
                                GetterPatient.id = i;
                                System.out.println("identifiant : "+i);
                            }
                        }catch(Exception e){
                            System.out.print("Probleme de lecture d'id Patient");
                            e.printStackTrace();
                        }
                        //connect2.close();
                        //*****************************************
                        
                        
                        
                        //affiche le message 'Ajoutez'
                        alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Votre santé, notre priorité.");
                        alert.setHeaderText(null);
                        alert.setContentText("Bienvenue !");
                        alert.showAndWait();
                        //connect.close();
                        goToNextPage();
                    }
                }else{
                    textError.setVisible(true);
                    alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Message d'erreur");
                    alert.setHeaderText(null);
                    alert.setContentText("S'il vous plait veuillez entrer des mots de passe identiques.");
                    alert.showAndWait();
                    
                    password1.setText("");
                    password2.setText("");
                }
            }
        }catch(Exception e){
            System.out.println("______________________Start Error______________________"+"\n");
            e.printStackTrace();
            System.out.println(".........Probleme de connexion.........");
        }
    }
    public void addPatientGenreList(){
        List<String> listS = new ArrayList<>();
        
        for(String Data : genreList){
            listS.add(Data);
        }
        
        ObservableList listD = FXCollections.observableArrayList(listS);
        textView_Genre.setItems(listD);
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        addPatientGenreList();
        textError.setVisible(false);
    }    
    
}
